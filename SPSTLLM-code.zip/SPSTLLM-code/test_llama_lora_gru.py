#!/usr/bin/env python3
"""
大模型 (Llama LoRA + GRU ST Encoder) 独立测试脚本
对标 test_gru_model.py，复用相同的指标统计与画图逻辑
"""

import os
import json
import argparse
import random

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
import torch.distributed as dist
import torch.multiprocessing as mp
import numpy as np
import pickle
from tqdm import tqdm
import matplotlib.pyplot as plt

from llama_lora_clean_gru import (
    GRUEncoder,
    LlamaLoRAPredictor,
    FlowQADataset,
    compute_metrics,
    parse_answer_text,
)


def set_seed(seed: int = 42, rank: int = 0) -> None:
    """设置随机种子，与训练脚本保持一致风格，保证多进程下结果可复现。"""
    seed = seed + rank
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_data_and_features(qa_data_dir, lookback=12, predict=12):
    """加载归一化数据、邻接矩阵，并构建与训练阶段一致的特征。
    基本对齐 llama_lora_clean_gru.main_worker 中的数据准备逻辑，只保留测试相关部分。
    """
    required_files = [
        'data_train_normalized.npy',
        'data_val_normalized.npy',
        'data_test_normalized.npy',
        'scaler.pkl',
        'adjacency_matrix.npy',
    ]
    missing = [f for f in required_files if not os.path.exists(os.path.join(qa_data_dir, f))]
    if missing:
        raise FileNotFoundError("缺少必需文件:\n" + "\n".join(f"  - {os.path.join(qa_data_dir, f)}" for f in missing))

    train_data = np.load(os.path.join(qa_data_dir, 'data_train_normalized.npy'))
    val_data = np.load(os.path.join(qa_data_dir, 'data_val_normalized.npy'))
    test_data = np.load(os.path.join(qa_data_dir, 'data_test_normalized.npy'))

    with open(os.path.join(qa_data_dir, 'scaler.pkl'), 'rb') as f:
        scaler = pickle.load(f)

    adj_matrix = np.load(os.path.join(qa_data_dir, 'adjacency_matrix.npy')).astype(np.float32)

    # 计算邻居聚合特征（与 llama_lora_clean_gru 保持一致）
    adj = adj_matrix.copy()
    np.fill_diagonal(adj, 1.0)
    row_sums = adj.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    adj_norm = adj / row_sums

    adj2 = adj_norm @ adj_norm
    row_sums2 = adj2.sum(axis=1, keepdims=True)
    row_sums2[row_sums2 == 0] = 1.0
    adj2_norm = adj2 / row_sums2

    train_neighbor_1hop = train_data @ adj_norm.T
    val_neighbor_1hop = val_data @ adj_norm.T
    test_neighbor_1hop = test_data @ adj_norm.T

    train_neighbor_2hop = train_data @ adj2_norm.T
    val_neighbor_2hop = val_data @ adj2_norm.T
    test_neighbor_2hop = test_data @ adj2_norm.T

    # 多尺度特征，与训练保持完全一致
    def compute_multiscale_features(data):
        T, N = data.shape
        multiscale = np.zeros((T, N, 3), dtype=np.float32)
        day_steps = 288
        week_steps = 288 * 7
        for t in range(T):
            if t >= day_steps:
                multiscale[t, :, 0] = data[t, :] - data[t - day_steps, :]
            if t >= week_steps:
                multiscale[t, :, 1] = data[t, :] - data[t - week_steps, :]
            if t >= 12:
                multiscale[t, :, 2] = data[t, :] - data[t-12:t, :].mean(axis=0)
        return multiscale

    train_multiscale = compute_multiscale_features(train_data)
    val_multiscale = compute_multiscale_features(val_data)
    test_multiscale = compute_multiscale_features(test_data)

    # 与训练脚本一致的时间索引划分
    train_timesteps = train_data.shape[0]
    val_timesteps = val_data.shape[0]
    train_end = train_timesteps
    val_end = train_end + val_timesteps

    # 这里只需要测试集 QA，所以直接构建 FlowQADataset 的 test 部分
    # 但为了与训练/验证同一套 JSON 编码方式保持一致，这里仍然使用 flow_test.json
    from llama_lora_clean_gru import precompute_gcn_embeddings, compute_node_features

    node_features = compute_node_features(train_data)
    # 这里在 CPU 上预计算即可，后续转到 GPU
    gcn_embeddings = precompute_gcn_embeddings(adj_matrix, node_features, gcn_output_dim=16, device='cpu')

    test_dataset = FlowQADataset(
        json_path=os.path.join(qa_data_dir, 'flow_test.json'),
        data_matrix=test_data,
        neighbor_1hop=test_neighbor_1hop,
        neighbor_2hop=test_neighbor_2hop,
        multiscale=test_multiscale,
        gcn_embeddings=gcn_embeddings,
        start_time_idx=val_end,
        lookback=lookback,
        predict=predict,
    )

    return {
        'train_data': train_data,
        'val_data': val_data,
        'test_data': test_data,
        'scaler': scaler,
        'adj_matrix': adj_matrix,
        'gcn_embeddings': gcn_embeddings,
        'test_dataset': test_dataset,
    }


def load_models(llama_model_path, st_encoder_path, device, lookback=12, predict=12):
    """加载 GRU ST Encoder 与 Llama LoRA 模型，用于推理。
    结构与 llama_lora_clean_gru.main_worker 中保持一致，但只做推理加载。
    """
    # GRU ST Encoder
    st_encoder = GRUEncoder(
        hidden_channels=1024,
        num_layers=8,
        dropout=0.06,
        lookback=lookback,
        out_dim=1024,
    ).to(device)

    st_encoder_loaded = False
    if os.path.exists(st_encoder_path):
        try:
            checkpoint = torch.load(st_encoder_path, map_location=device)
            model_dict = st_encoder.state_dict()
            compatible_dict = {}
            for k, v in checkpoint.items():
                if k in model_dict and model_dict[k].shape == v.shape:
                    compatible_dict[k] = v
            model_dict.update(compatible_dict)
            st_encoder.load_state_dict(model_dict, strict=False)
            st_encoder.eval()
            for param in st_encoder.parameters():
                param.requires_grad = False
            print(f"GRU ST Encoder已加载并冻结: {st_encoder_path}")
            print(f"   加载了 {len(compatible_dict)} 个兼容的层")
            st_encoder_loaded = True
        except Exception as e:
            print(f"GRU ST Encoder加载失败: {e}")
    if not st_encoder_loaded:
        print("将使用随机初始化的GRU Encoder（仅用于辅助特征）")

    # Llama LoRA 模型
    model = LlamaLoRAPredictor(
        llama_model_path=llama_model_path,
        st_hidden_dim=1024,
        spatial_dim=16,
        lora_r=16,
        lora_alpha=32,
        dropout=0.1,
    )
    model = model.to(device)

    # 尝试加载已微调的 LoRA 权重（兼容 DataParallel/DDP 保存方式）
    lora_ckpt_path = os.path.join(os.path.dirname(st_encoder_path), 'llama_lora_model_gru.pth')
    if os.path.exists(lora_ckpt_path):
        try:
            state = torch.load(lora_ckpt_path, map_location='cpu')
            new_state = {}
            for k, v in state.items():
                if k.startswith('module.'):
                    new_state[k[7:]] = v
                else:
                    new_state[k] = v
            model.load_state_dict(new_state, strict=False)
            print(f"Llama LoRA 模型权重已加载: {lora_ckpt_path}")
            print(f"   加载了 {len(new_state)} 个参数")
        except Exception as e:
            print(f"加载 Llama LoRA 权重失败，将使用基础模型: {e}")
    else:
        print(f"未找到 Llama LoRA 权重文件: {lora_ckpt_path}，将使用基础模型结构")

    model.eval()
    return st_encoder, model


def evaluate_llama_on_test(model, st_encoder, test_loader, device, scaler, lookback=12, predict=12, is_main=True):
    """参照 test_gru_model.py 的评估与画图统计逻辑，对大模型进行测试。
    与 llama_lora_clean_gru.evaluate_and_collect_stats 类似，但输出统计结构对齐 test_gru_model.py。
    """
    if is_main:
        print("\n" + "=" * 60)
        print("开始大模型测试 (Llama LoRA + GRU Encoder)...")
        print("=" * 60)

    total_mae = 0.0
    total_rmse = 0.0
    total_mape = 0.0
    num_samples = 0

    horizon = predict

    # 每个 horizon 的指标
    mae_per_h = np.zeros(horizon)
    rmse_per_h = np.zeros(horizon)
    mape_per_h = np.zeros(horizon)
    count_per_h = np.zeros(horizon)

    # 时间序列预测数据（用于画图）
    # 需要知道 test_data 的 shape，这里通过 loader.dataset.data_matrix 获得
    data_matrix = test_loader.dataset.data_matrix
    num_timesteps, num_nodes = data_matrix.shape
    pred_series = np.zeros((num_timesteps, num_nodes), dtype=np.float32)
    pred_counts = np.zeros((num_timesteps, num_nodes), dtype=np.float32)

    debug_samples = []
    max_debug_samples = 100

    data_range = scaler.data_range_.mean()

    with torch.no_grad():
        for batch_data in tqdm(test_loader, desc="Testing (Llama)", disable=not is_main):
            x, n1, n2, ms, time_feat, spatial_enc, y, y_text, meta_info = batch_data
            x = x.to(device)
            n1 = n1.to(device)
            n2 = n2.to(device)
            ms = ms.to(device)
            time_feat = time_feat.to(device)
            spatial_enc = spatial_enc.to(device)
            y = y.to(device)
            meta_info = meta_info.cpu().numpy()

            st_features = None
            if st_encoder is not None:
                st_features = st_encoder(x, n1, n2, ms, time_feat)

            try:
                generated_texts = model.forward_generate(
                    x, spatial_enc, st_features,
                    instruction="Predict the next 12 time steps of traffic flow based on historical data and spatial context.",
                    max_new_tokens=100,
                )

                B = x.size(0)
                for i in range(B):
                    text = generated_texts[i]
                    pred_values = parse_answer_text(text)
                    if pred_values is not None:
                        pred_values = pred_values.to(device)
                        pred_values = torch.clamp(pred_values, 0.0, 1.0)
                    else:
                        pred_values = torch.full((horizon,), 0.5, device=device)

                    mae, rmse, mape = compute_metrics(pred_values, y[i], scaler)
                    total_mae += mae
                    total_rmse += rmse
                    total_mape += mape
                    num_samples += 1

                    pv_np = pred_values.detach().cpu().numpy()
                    y_np = y[i].detach().cpu().numpy()

                    for h in range(horizon):
                        diff = np.abs(pv_np[h] - y_np[h])
                        mae_per_h[h] += diff
                        rmse_per_h[h] += diff**2
                        if np.abs(y_np[h]) > 1e-6:
                            mape_per_h[h] += np.abs((pv_np[h] - y_np[h]) / y_np[h])
                        count_per_h[h] += 1

                    # 时间序列重建
                    t_idx, node_idx = meta_info[i]
                    t_idx = int(t_idx)
                    node_idx = int(node_idx)
                    for h in range(horizon):
                        target_t = t_idx + lookback + h
                        if 0 <= target_t < num_timesteps:
                            pred_series[target_t, node_idx] += pv_np[h]
                            pred_counts[target_t, node_idx] += 1

                    if len(debug_samples) < max_debug_samples:
                        debug_samples.append({
                            'sample_idx': num_samples,
                            't_idx': int(t_idx),
                            'node_idx': int(node_idx),
                            'x': x[i].detach().cpu().tolist(),
                            'y_true': y[i].detach().cpu().tolist(),
                            'y_pred': pv_np.tolist(),
                            'mae': float(mae),
                            'raw_text': text,
                        })

            except Exception as e:
                print(f"\n⚠️ Error in batch evaluation: {e}")
                continue

    avg_mae = total_mae / max(num_samples, 1)
    avg_rmse = total_rmse / max(num_samples, 1)
    avg_mape = total_mape / max(num_samples, 1)

    mae_per_h /= np.maximum(count_per_h, 1)
    rmse_per_h = np.sqrt(rmse_per_h / np.maximum(count_per_h, 1))
    mape_per_h = 100 * mape_per_h / np.maximum(count_per_h, 1)

    actual_mae = avg_mae * data_range
    actual_rmse = avg_rmse * data_range

    metrics = {
        'avg_mae': float(avg_mae),
        'avg_rmse': float(avg_rmse),
        'avg_mape': float(avg_mape),
        'actual_mae': float(actual_mae),
        'actual_rmse': float(actual_rmse),
        'data_range': float(data_range),
        'horizon': horizon,
        'mae_per_h': mae_per_h,
        'rmse_per_h': rmse_per_h,
        'mape_per_h': mape_per_h,
        'count_per_h': count_per_h,
        'num_samples': int(num_samples),
        'pred_series': pred_series,
        'pred_counts': pred_counts,
        'debug_samples': debug_samples,
        'num_timesteps': int(num_timesteps),
        'num_nodes': int(num_nodes),
    }

    return metrics


def aggregate_metrics_ddp(local_metrics, device):
    """在多进程 DDP 场景下聚合各 rank 的指标和时间序列，只在 rank0 使用聚合后的结果。"""
    if not dist.is_initialized() or dist.get_world_size() == 1:
        return local_metrics

    horizon = local_metrics['horizon']

    # 标量：使用加权和再除以总样本数
    local_num = float(local_metrics['num_samples'])
    local_weighted = torch.tensor([
        local_metrics['avg_mae'] * local_num,
        local_metrics['avg_rmse'] * local_num,
        local_metrics['avg_mape'] * local_num,
        local_num,
    ], device=device, dtype=torch.float32)
    dist.all_reduce(local_weighted, op=dist.ReduceOp.SUM)
    total_mae_w, total_rmse_w, total_mape_w, total_num = local_weighted.tolist()
    total_num = max(total_num, 1.0)

    global_avg_mae = total_mae_w / total_num
    global_avg_rmse = total_rmse_w / total_num
    global_avg_mape = total_mape_w / total_num

    # per-horizon 指标：按样本数加权
    local_count_per_h = local_metrics['count_per_h'].astype(np.float32)
    local_mae_per_h = local_metrics['mae_per_h'].astype(np.float32)
    local_rmse_per_h = local_metrics['rmse_per_h'].astype(np.float32)
    local_mape_per_h = local_metrics['mape_per_h'].astype(np.float32)

    mae_sum = torch.from_numpy(local_mae_per_h * local_count_per_h).to(device)
    mse_sum = torch.from_numpy((local_rmse_per_h ** 2) * local_count_per_h).to(device)
    mape_sum = torch.from_numpy(local_mape_per_h * local_count_per_h).to(device)
    count_sum = torch.from_numpy(local_count_per_h).to(device)

    for t in (mae_sum, mse_sum, mape_sum, count_sum):
        dist.all_reduce(t, op=dist.ReduceOp.SUM)

    count_clamped = torch.clamp(count_sum, min=1.0)
    global_mae_per_h = (mae_sum / count_clamped).cpu().numpy()
    global_rmse_per_h = torch.sqrt(mse_sum / count_clamped).cpu().numpy()
    global_mape_per_h = (mape_sum / count_clamped).cpu().numpy()

    # 时间序列：直接对 pred_series / pred_counts 做求和
    pred_series_t = torch.from_numpy(local_metrics['pred_series'].astype(np.float32)).to(device)
    pred_counts_t = torch.from_numpy(local_metrics['pred_counts'].astype(np.float32)).to(device)
    dist.all_reduce(pred_series_t, op=dist.ReduceOp.SUM)
    dist.all_reduce(pred_counts_t, op=dist.ReduceOp.SUM)

    global_pred_series = pred_series_t.cpu().numpy()
    global_pred_counts = pred_counts_t.cpu().numpy()

    # 其它元数据在各 rank 相同，直接复用本地的
    global_metrics = dict(local_metrics)
    global_metrics['avg_mae'] = float(global_avg_mae)
    global_metrics['avg_rmse'] = float(global_avg_rmse)
    global_metrics['avg_mape'] = float(global_avg_mape)
    global_metrics['mae_per_h'] = global_mae_per_h
    global_metrics['rmse_per_h'] = global_rmse_per_h
    global_metrics['mape_per_h'] = global_mape_per_h
    global_metrics['pred_series'] = global_pred_series
    global_metrics['pred_counts'] = global_pred_counts
    global_metrics['num_samples'] = int(total_num)

    return global_metrics


def plot_and_save_results(metrics, test_data, output_dir, prefix="llama_gru_test"):
    """严格复用 test_gru_model.py 的画图逻辑，只是文件名前加前缀。"""
    os.makedirs(output_dir, exist_ok=True)

    avg_mae = metrics['avg_mae']
    avg_rmse = metrics['avg_rmse']
    avg_mape = metrics['avg_mape']
    actual_mae = metrics['actual_mae']
    actual_rmse = metrics['actual_rmse']
    data_range = metrics['data_range']
    horizon = metrics['horizon']
    mae_per_h = metrics['mae_per_h']
    rmse_per_h = metrics['rmse_per_h']
    mape_per_h = metrics['mape_per_h']
    num_samples = metrics['num_samples']
    pred_series = metrics['pred_series']
    pred_counts = metrics['pred_counts']
    num_timesteps = metrics['num_timesteps']
    num_nodes = metrics['num_nodes']

    debug_samples = metrics['debug_samples']

    print("\n" + "=" * 60)
    print("Llama LoRA + GRU 小模型测试结果")
    print("=" * 60)
    print(f"测试样本数: {num_samples}")
    print(f"\n归一化指标:")
    print(f"  MAE:  {avg_mae:.4f}")
    print(f"  RMSE: {avg_rmse:.4f}")
    print(f"  MAPE: {avg_mape:.2f}%")
    print(f"\n实际尺度指标 (× {data_range:.2f}):")
    print(f"  MAE:  {actual_mae:.2f}")
    print(f"  RMSE: {actual_rmse:.2f}")
    print("=" * 60)

    print("\n每个预测步的 MAE (实际尺度):")
    for h in range(horizon):
        print(f"  H{h+1:2d}: {mae_per_h[h] * data_range:.2f}")

    results = {
        'normalized_mae': float(avg_mae),
        'normalized_rmse': float(avg_rmse),
        'mape': float(avg_mape),
        'actual_mae': float(actual_mae),
        'actual_rmse': float(actual_rmse),
        'mae_per_horizon': (mae_per_h * data_range).tolist(),
        'rmse_per_horizon': (rmse_per_h * data_range).tolist(),
        'mape_per_horizon': mape_per_h.tolist(),
        'num_samples': num_samples,
    }

    results_path = os.path.join(output_dir, f'{prefix}_results.json')
    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {results_path}")

    print("\n生成图表...")

    mae_per_h_actual = mae_per_h * data_range
    rmse_per_h_actual = rmse_per_h * data_range
    horizons = np.arange(1, horizon + 1)

    # 1) MAE per horizon
    plt.figure(figsize=(10, 6))
    plt.plot(horizons, mae_per_h_actual, marker='o', color='steelblue', linewidth=2, markersize=8)
    plt.xlabel('Prediction Horizon', fontsize=12)
    plt.ylabel('MAE (Actual Scale)', fontsize=12)
    plt.title('GRU Model - MAE by Prediction Horizon', fontsize=14)
    plt.xticks(horizons)
    y_max = max(mae_per_h_actual) * 1.15 if len(mae_per_h_actual) > 0 else 1.0
    plt.ylim(0, y_max)
    plt.grid(True, alpha=0.3)
    for i, v in enumerate(mae_per_h_actual):
        plt.text(i+1, v + y_max * 0.02, f'{v:.1f}', ha='center', fontsize=9)
    plt.tight_layout()
    mae_path = os.path.join(output_dir, f'{prefix}_horizon_mae.png')
    plt.savefig(mae_path)
    plt.close()

    # 2) RMSE per horizon
    plt.figure(figsize=(10, 6))
    plt.plot(horizons, rmse_per_h_actual, marker='s', color='coral', linewidth=2, markersize=8)
    plt.xlabel('Prediction Horizon', fontsize=12)
    plt.ylabel('RMSE (Actual Scale)', fontsize=12)
    plt.title('GRU Model - RMSE by Prediction Horizon', fontsize=14)
    plt.xticks(horizons)
    y_max = max(rmse_per_h_actual) * 1.15 if len(rmse_per_h_actual) > 0 else 1.0
    plt.ylim(0, y_max)
    plt.grid(True, alpha=0.3)
    for i, v in enumerate(rmse_per_h_actual):
        plt.text(i+1, v + y_max * 0.02, f'{v:.1f}', ha='center', fontsize=9)
    plt.tight_layout()
    rmse_path = os.path.join(output_dir, f'{prefix}_horizon_rmse.png')
    plt.savefig(rmse_path)
    plt.close()

    # 3) MAPE per horizon
    plt.figure(figsize=(10, 6))
    plt.plot(horizons, mape_per_h, marker='^', color='forestgreen', linewidth=2, markersize=8)
    plt.xlabel('Prediction Horizon', fontsize=12)
    plt.ylabel('MAPE (%)', fontsize=12)
    plt.title('GRU Model - MAPE by Prediction Horizon', fontsize=14)
    plt.xticks(horizons)
    y_max = max(mape_per_h) * 1.15 if len(mape_per_h) > 0 else 1.0
    plt.ylim(0, y_max)
    plt.grid(True, alpha=0.3)
    for i, v in enumerate(mape_per_h):
        plt.text(i+1, v + y_max * 0.02, f'{v:.1f}%', ha='center', fontsize=9)
    plt.tight_layout()
    mape_path = os.path.join(output_dir, f'{prefix}_horizon_mape.png')
    plt.savefig(mape_path)
    plt.close()

    # 4) 时间序列对比（两个节点）
    pred_avg = np.divide(pred_series, pred_counts, where=pred_counts > 0, out=np.zeros_like(pred_series))
    pred_avg_actual = pred_avg * data_range
    true_actual = test_data * data_range

    node1, node2 = 0, min(50, num_nodes - 1)

    fig, axes = plt.subplots(2, 1, figsize=(16, 8), sharex=True)
    for ax, node in zip(axes, [node1, node2]):
        ax.plot(range(num_timesteps), true_actual[:, node], label='True', alpha=0.7, linewidth=0.8)
        ax.plot(range(num_timesteps), pred_avg_actual[:, node], label='Predicted', alpha=0.7, linewidth=0.8, linestyle='--')
        ax.set_ylabel(f'Node {node} Flow', fontsize=11)
        ax.legend(loc='upper right')
        ax.grid(alpha=0.3)
    axes[0].set_title('GRU Model - Traffic Flow Prediction vs Ground Truth', fontsize=14)
    axes[1].set_xlabel('Time Step', fontsize=12)
    plt.tight_layout()
    ts_path = os.path.join(output_dir, f'{prefix}_two_nodes_prediction.png')
    plt.savefig(ts_path)
    plt.close()

    print(f"\n图表已保存:")
    print(f"   MAE:  {mae_path}")
    print(f"   RMSE: {rmse_path}")
    print(f"   MAPE: {mape_path}")
    print(f"   时间序列: {ts_path}")

    # 在 JSON 中补充画图数据，与 test_gru_model.py 对齐
    results['node_ids'] = [node1, node2]
    results['node_true'] = {
        str(node1): true_actual[:, node1].tolist(),
        str(node2): true_actual[:, node2].tolist(),
    }
    results['node_pred'] = {
        str(node1): pred_avg_actual[:, node1].tolist(),
        str(node2): pred_avg_actual[:, node2].tolist(),
    }

    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"   结果 JSON (含画图数据): {results_path}")

    # 额外保存一份专用于画图的数据，结构与 new_exp/test_plot_data.json 一致
    plot_data = {
        'horizons': list(range(1, horizon + 1)),
        'mae_per_horizon': mae_per_h_actual.tolist(),
        'rmse_per_horizon': rmse_per_h_actual.tolist(),
        'mape_per_horizon': mape_per_h.tolist(),
        'node_ids': [node1, node2],
        'node_true': {
            str(node1): true_actual[:, node1].tolist(),
            str(node2): true_actual[:, node2].tolist(),
        },
        'node_pred': {
            str(node1): pred_avg_actual[:, node1].tolist(),
            str(node2): pred_avg_actual[:, node2].tolist(),
        },
    }
    plot_data_path = os.path.join(output_dir, 'test_plot_data.json')
    with open(plot_data_path, 'w', encoding='utf-8') as f:
        json.dump(plot_data, f, ensure_ascii=False, indent=2)
    print(f"   画图数据 JSON: {plot_data_path}")

    print("\n" + "=" * 60)
    print("大模型测试完成!")
    print("=" * 60)


def main_worker(rank, world_size, gpu_ids, args):
    """每个 GPU 进程的主函数，用于 DDP 测试评估。"""
    local_gpu_id = gpu_ids[rank]
    torch.cuda.set_device(local_gpu_id)
    device = torch.device(f'cuda:{local_gpu_id}' if torch.cuda.is_available() else 'cpu')

    if world_size > 1:
        os.environ['MASTER_ADDR'] = 'localhost'
        os.environ['MASTER_PORT'] = args.master_port
        dist.init_process_group("nccl", rank=rank, world_size=world_size)

    set_seed(42, rank)
    is_main = (rank == 0)

    if is_main:
        print("=" * 60)
        print("Llama LoRA + GRU ST Encoder 大模型独立测试脚本 (DDP)")
        print("=" * 60)
        print(f"Llama 模型路径: {args.llama_model_path}")
        print(f"ST Encoder 路径: {args.st_encoder_path}")
        print(f"数据目录: {args.qa_data_dir}")
        print(f"输出目录: {args.output_dir}")
        print(f"使用 GPU: {gpu_ids} (world_size={world_size})")
        print("=" * 60)

    # 所有 rank 加载相同的数据与特征，使用 DistributedSampler 划分样本
    if is_main:
        print("\n加载数据与特征...")
    data_bundle = load_data_and_features(args.qa_data_dir, lookback=12, predict=12)
    scaler = data_bundle['scaler']
    test_data = data_bundle['test_data']
    test_dataset = data_bundle['test_dataset']

    if world_size > 1:
        test_sampler = DistributedSampler(test_dataset, num_replicas=world_size, rank=rank, shuffle=False)
    else:
        test_sampler = None

    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=(test_sampler is None),
        sampler=test_sampler,
        num_workers=args.num_workers,
        pin_memory=True,
    )

    if is_main:
        print("\n加载模型...")
    st_encoder, model = load_models(args.llama_model_path, args.st_encoder_path, device, lookback=12, predict=12)

    # 评估（各 rank 处理各自划分的数据）
    local_metrics = evaluate_llama_on_test(
        model,
        st_encoder,
        test_loader,
        device,
        scaler,
        lookback=12,
        predict=12,
        is_main=is_main,
    )

    # 聚合多卡指标和时间序列
    global_metrics = aggregate_metrics_ddp(local_metrics, device)

    # 仅 rank0 负责画图和保存结果
    if is_main:
        plot_and_save_results(global_metrics, test_data, args.output_dir, prefix="llama_gru_test")

    if world_size > 1:
        dist.destroy_process_group()


def main():
    parser = argparse.ArgumentParser(description='Llama LoRA + GRU ST Encoder 大模型独立测试脚本 (DDP)')
    parser.add_argument('--qa_data_dir', type=str,
                        default='/data/wangyuehao/preflows/urbangpt_new/qa_data',
                        help='QA 数据目录')
    parser.add_argument('--llama_model_path', type=str,
                        default='/data/wangyuehao/preflows/meta-llama/Llama-3.2-1B',
                        help='Llama 模型路径')
    parser.add_argument('--st_encoder_path', type=str,
                        default='/data/wangyuehao/preflows/urbangpt_new/best_model_time_gru_12.96.pth',
                        help='GRU ST Encoder 模型路径')
    parser.add_argument('--output_dir', type=str,
                        default='/data/wangyuehao/preflows/urbangpt_new/llama_gru_test_results',
                        help='输出目录')
    parser.add_argument('--batch_size', type=int, default=96, help='每卡批次大小')
    parser.add_argument('--gpu_ids', type=str, default='0,1',
                        help='使用的 GPU 编号，用逗号分隔，例如 0,1,2')
    parser.add_argument('--num_workers', type=int, default=4, help='DataLoader 的 num_workers')
    parser.add_argument('--master_port', type=str, default='12365', help='DDP master port')

    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    gpu_ids = [int(x.strip()) for x in args.gpu_ids.split(',') if x.strip() != '']
    if not gpu_ids or not torch.cuda.is_available():
        # 无 GPU 或未指定 GPU，退化为单进程 CPU/单卡测试
        device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        set_seed(42, 0)
        print("=" * 60)
        print("Llama LoRA + GRU ST Encoder 大模型独立测试脚本 (单进程)")
        print("=" * 60)
        print(f"Llama 模型路径: {args.llama_model_path}")
        print(f"ST Encoder 路径: {args.st_encoder_path}")
        print(f"数据目录: {args.qa_data_dir}")
        print(f"输出目录: {args.output_dir}")
        print("=" * 60)

        print("\n加载数据与特征...")
        data_bundle = load_data_and_features(args.qa_data_dir, lookback=12, predict=12)
        scaler = data_bundle['scaler']
        test_data = data_bundle['test_data']
        test_dataset = data_bundle['test_dataset']

        test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)

        print("\n加载模型...")
        st_encoder, model = load_models(args.llama_model_path, args.st_encoder_path, device, lookback=12, predict=12)

        metrics = evaluate_llama_on_test(
            model,
            st_encoder,
            test_loader,
            device,
            scaler,
            lookback=12,
            predict=12,
            is_main=True,
        )
        plot_and_save_results(metrics, test_data, args.output_dir, prefix="llama_gru_test")
    else:
        world_size = len(gpu_ids)
        print("=" * 60)
        print("Llama LoRA + GRU ST Encoder 大模型独立测试脚本 (DDP)")
        print("=" * 60)
        print(f"使用 GPU: {gpu_ids} (world_size={world_size})")
        print(f"每卡 Batch Size: {args.batch_size}")
        print(f"总有效 Batch Size: {args.batch_size * world_size}")
        print("=" * 60)

        mp.spawn(
            main_worker,
            args=(world_size, gpu_ids, args),
            nprocs=world_size,
            join=True,
        )


if __name__ == '__main__':
    main()
