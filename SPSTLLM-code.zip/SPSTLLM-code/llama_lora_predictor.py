#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
import json
from tqdm import tqdm
import time
import os
import re
import warnings
import pickle
import argparse
warnings.filterwarnings('ignore')


def construct_adjacency_matrix(data, threshold=0.5, method='pearson'):
    num_timesteps, num_nodes = data.shape
    adj_matrix = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    
    if method == 'pearson':
        from scipy.stats import pearsonr
        for i in range(num_nodes):
            for j in range(i, num_nodes):
                if i == j:
                    adj_matrix[i, j] = 1.0
                else:
                    corr, _ = pearsonr(data[:, i], data[:, j])
                    corr = abs(corr)
                    if corr >= threshold:
                        adj_matrix[i, j] = corr
                        adj_matrix[j, i] = corr
    
    elif method == 'cosine':
        from sklearn.metrics.pairwise import cosine_similarity
        similarity_matrix = cosine_similarity(data.T)
        adj_matrix = np.where(similarity_matrix >= threshold, similarity_matrix, 0)
    
    num_edges = (adj_matrix > 0).sum() - num_nodes
    print(f"邻接矩阵: {adj_matrix.shape}, 边数: {num_edges}")
    
    return adj_matrix


class SimpleGCN(nn.Module):
    def __init__(self, input_dim=1, hidden_dim=32, output_dim=16, dropout=0.1):
        super().__init__()
        self.gc1 = nn.Linear(input_dim, hidden_dim)
        self.gc2 = nn.Linear(hidden_dim, output_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.ReLU()
        
    def forward(self, x, adj):
        adj = adj + torch.eye(adj.size(0), device=adj.device)
        rowsum = adj.sum(1)
        d_inv_sqrt = torch.pow(rowsum, -0.5)
        d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.
        d_mat_inv_sqrt = torch.diag(d_inv_sqrt)
        adj_normalized = d_mat_inv_sqrt @ adj @ d_mat_inv_sqrt
        
        h = self.gc1(adj_normalized @ x)
        h = self.activation(h)
        h = self.dropout(h)
        h = self.gc2(adj_normalized @ h)
        
        return h


def compute_node_features(data):
    num_timesteps, num_nodes = data.shape
    features = []
    
    for i in range(num_nodes):
        node_data = data[:, i]
        features.append([
            node_data.mean(),
            node_data.std(),
            node_data.max(),
            node_data.min(),
            np.percentile(node_data, 75),
            np.percentile(node_data, 25),
        ])
    
    node_features = np.array(features, dtype=np.float32)
    print(f"节点特征: {node_features.shape}")
    return node_features


def precompute_gcn_embeddings(adj_matrix, node_features, gcn_output_dim=16, device='cpu'):
    num_nodes, feature_dim = node_features.shape
    gcn = SimpleGCN(input_dim=feature_dim, hidden_dim=32, output_dim=gcn_output_dim).to(device)
    adj_tensor = torch.FloatTensor(adj_matrix).to(device)
    node_features_tensor = torch.FloatTensor(node_features).to(device)
    
    with torch.no_grad():
        node_embeddings = gcn(node_features_tensor, adj_tensor)
    
    print(f"GCN嵌入: {node_embeddings.shape}")
    return node_embeddings.cpu()


def format_answer_text(y_values):
    if isinstance(y_values, torch.Tensor):
        y_values = y_values.cpu().numpy()
    
    values_str = ', '.join([f"{v:.2f}" for v in y_values])
    answer_text = f"The predicted traffic flow is: [{values_str}]"
    
    return answer_text


def parse_answer_text(text):
    try:
        match = re.search(r'\[(.*?)\]', text)
        if match:
            content = match.group(1)
            numbers = [float(x.strip()) for x in content.split(',')]
            if len(numbers) == 12:
                return torch.tensor(numbers, dtype=torch.float32)
        return None
    except:
        return None


class FlowDataset(Dataset):
    def __init__(self, data, gcn_embeddings=None, lookback=12, predict=12):
        self.data = data
        self.gcn_embeddings = gcn_embeddings
        self.lookback = lookback
        self.predict = predict
        self.num_timesteps, self.num_nodes = data.shape
        
        self.samples = []
        max_idx = self.num_timesteps - lookback - predict + 1
        
        for t in range(max_idx):
            for node in range(self.num_nodes):
                self.samples.append((t, node))
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        t, node = self.samples[idx]
        x = self.data[t:t+self.lookback, node]
        y = self.data[t+self.lookback:t+self.lookback+self.predict, node]
        
        if self.gcn_embeddings is not None:
            spatial_enc = self.gcn_embeddings[node]
        else:
            spatial_enc = torch.zeros(16, dtype=torch.float32)
        
        y_text = format_answer_text(y)
        
        return torch.FloatTensor(x), torch.FloatTensor(spatial_enc), torch.FloatTensor(y), y_text


class STEncoder(nn.Module):
    def __init__(self, hidden_dim=512, num_layers=5, dropout=0.2, lookback=12):
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lookback = lookback
        
        self.pos_encoding = nn.Parameter(torch.randn(1, lookback, 24))
        # 🔥 添加时间特征支持：1 + 24 + 4 + 6 = 35维
        self.feature_dim = 1 + 24 + 4 + 6
        
        self.lstm = nn.LSTM(
            input_size=self.feature_dim,
            hidden_size=hidden_dim // 2,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=True
        )
        
        self.layer_norm = nn.LayerNorm(hidden_dim)
        
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.Tanh(),
            nn.Linear(hidden_dim // 2, 1)
        )
        
        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.LayerNorm(hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 12)
        )
        
        self.baseline_proj = nn.Linear(lookback, 12)
    
    def extract_temporal_features(self, batch_size, start_idx=0):
        """提取时间特征（模拟，因为我们没有真实时间戳）"""
        time_features = []
        for b in range(batch_size):
            batch_features = []
            for t in range(self.lookback):
                # 假设数据是5分钟间隔，一天288个时间步
                timestamp_idx = start_idx + t
                minutes = timestamp_idx * 5
                hour = (minutes // 60) % 24
                day_of_week = (timestamp_idx // 288) % 7
                
                features = [
                    np.sin(2 * np.pi * hour / 24),      # 小时正弦
                    np.cos(2 * np.pi * hour / 24),      # 小时余弦
                    np.sin(2 * np.pi * day_of_week / 7),  # 星期正弦
                    np.cos(2 * np.pi * day_of_week / 7),  # 星期余弦
                    1.0 if hour in [7, 8, 9, 17, 18, 19] else 0.0,  # 高峰期
                    1.0 if day_of_week >= 5 else 0.0,  # 周末
                ]
                batch_features.append(features)
            time_features.append(batch_features)
        return torch.FloatTensor(time_features)  # (batch, lookback, 6)
    
    def forward(self, x):
        batch_size = x.size(0)
        device = x.device
        
        x_feat = x.unsqueeze(-1)
        pos_enc = self.pos_encoding.expand(batch_size, -1, -1)
        
        mean = x.mean(dim=1, keepdim=True).unsqueeze(-1).expand(-1, self.lookback, 1)
        std = x.std(dim=1, keepdim=True).unsqueeze(-1).expand(-1, self.lookback, 1) + 1e-6
        max_val = x.max(dim=1, keepdim=True)[0].unsqueeze(-1).expand(-1, self.lookback, 1)
        min_val = x.min(dim=1, keepdim=True)[0].unsqueeze(-1).expand(-1, self.lookback, 1)
        
        # 🔥 添加时间特征
        time_features = self.extract_temporal_features(batch_size).to(device)
        
        x_enhanced = torch.cat([x_feat, pos_enc, mean, std, max_val, min_val, time_features], dim=-1)
        
        lstm_out, _ = self.lstm(x_enhanced)
        lstm_out = self.layer_norm(lstm_out)
        
        attn_scores = self.attention(lstm_out)
        attn_weights = torch.softmax(attn_scores, dim=1)
        context = (lstm_out * attn_weights).sum(dim=1)
        
        return context


class LlamaLoRAPredictor(nn.Module):
    def __init__(self, llama_model_path, st_hidden_dim=1024, spatial_dim=6,
                 lora_r=16, lora_alpha=32, dropout=0.1):
        super().__init__()
        
        from transformers import AutoModelForCausalLM, AutoTokenizer
        
        self.tokenizer = AutoTokenizer.from_pretrained(llama_model_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        self.llama = AutoModelForCausalLM.from_pretrained(
            llama_model_path,
            torch_dtype=torch.bfloat16,
            device_map=None,
            low_cpu_mem_usage=True
        )
        
        self.hidden_size = self.llama.config.hidden_size
        
        from peft import LoraConfig, get_peft_model, TaskType
        
        lora_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=dropout,
            target_modules=["q_proj", "v_proj"],
            bias="none",
        )
        
        self.llama = get_peft_model(self.llama, lora_config)
        self.llama.print_trainable_parameters()
        
        self.st_projector = nn.Sequential(
            nn.Linear(st_hidden_dim, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(1024, self.hidden_size),
            nn.LayerNorm(self.hidden_size)
        )
        
        self.spatial_projector = nn.Sequential(
            nn.Linear(spatial_dim, 128),
            nn.LayerNorm(128),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(128, self.hidden_size),
            nn.LayerNorm(self.hidden_size)
        )
        
        self._init_weights()
    
    def _init_weights(self):
        for module in [self.st_projector, self.spatial_projector]:
            for m in module.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight, gain=0.01)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
    
    def forward_train(self, x, spatial_enc, st_features, y_text, instruction=None):
        batch_size = x.size(0)
        device = x.device
        
        if instruction is None:
            instruction = "Predict the next 12 time steps of traffic flow based on historical data and spatial context."
        
        question_tokens = self.tokenizer(
            [instruction] * batch_size,
            return_tensors='pt',
            padding=True,
            truncation=True,
            max_length=64
        ).to(device)
        
        question_embs = self.llama.get_base_model().model.embed_tokens(
            question_tokens['input_ids']
        )
        
        if st_features is not None:
            st_embs = self.st_projector(st_features.to(torch.float32))
            st_embs = st_embs.unsqueeze(1).to(torch.bfloat16)
        else:
            st_embs = torch.zeros(batch_size, 1, self.hidden_size, 
                                 dtype=torch.bfloat16, device=device)
        
        spatial_embs = self.spatial_projector(spatial_enc.to(torch.float32))
        spatial_embs = spatial_embs.unsqueeze(1).to(torch.bfloat16)
        
        flow_tokens = (x * 1000).long() + 5000
        flow_tokens = torch.clamp(flow_tokens, 0, self.tokenizer.vocab_size - 1)
        flow_embs = self.llama.get_base_model().model.embed_tokens(flow_tokens)
        
        answer_tokens = self.tokenizer(
            y_text,
            return_tensors='pt',
            padding=True,
            truncation=True,
            max_length=128
        ).to(device)
        
        answer_embs = self.llama.get_base_model().model.embed_tokens(
            answer_tokens['input_ids']
        )
        
        combined_embs = torch.cat([
            question_embs,
            st_embs,
            spatial_embs,
            flow_embs,
            answer_embs
        ], dim=1)
        
        q_len = question_tokens['input_ids'].size(1)
        a_len = answer_tokens['input_ids'].size(1)
        total_len = combined_embs.size(1)
        
        attention_mask = torch.ones(batch_size, total_len, device=device)
        labels = torch.full((batch_size, total_len), -100, dtype=torch.long, device=device)
        answer_start = q_len + 1 + 1 + 12
        labels[:, answer_start:answer_start+a_len] = answer_tokens['input_ids']
        
        outputs = self.llama(
            inputs_embeds=combined_embs,
            attention_mask=attention_mask,
            labels=labels,
            return_dict=True
        )
        
        return outputs.loss
    
    def forward_generate(self, x, spatial_enc, st_features, instruction=None, max_new_tokens=100):
        batch_size = x.size(0)
        device = x.device
        
        if instruction is None:
            instruction = "Predict the next 12 time steps of traffic flow based on historical data and spatial context."
        
        question_tokens = self.tokenizer(
            [instruction] * batch_size,
            return_tensors='pt',
            padding=True,
            truncation=True,
            max_length=64
        ).to(device)
        
        question_embs = self.llama.get_base_model().model.embed_tokens(
            question_tokens['input_ids']
        )
        
        if st_features is not None:
            st_embs = self.st_projector(st_features.to(torch.float32))
            st_embs = st_embs.unsqueeze(1).to(torch.bfloat16)
        else:
            st_embs = torch.zeros(batch_size, 1, self.hidden_size, 
                                 dtype=torch.bfloat16, device=device)
        
        spatial_embs = self.spatial_projector(spatial_enc.to(torch.float32))
        spatial_embs = spatial_embs.unsqueeze(1).to(torch.bfloat16)
        
        flow_tokens = (x * 1000).long() + 5000
        flow_tokens = torch.clamp(flow_tokens, 0, self.tokenizer.vocab_size - 1)
        flow_embs = self.llama.get_base_model().model.embed_tokens(flow_tokens)
        
        combined_embs = torch.cat([
            question_embs,
            st_embs,
            spatial_embs,
            flow_embs
        ], dim=1)
        
        attention_mask = torch.ones(batch_size, combined_embs.size(1), device=device)
        
        with torch.no_grad():
            outputs = self.llama.generate(
                inputs_embeds=combined_embs,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
        
        generated_texts = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        
        return generated_texts


def train_epoch(model, loader, optimizer, device, st_encoder=None, instruction=None):
    model.train()
    if st_encoder is not None:
        st_encoder.eval()
    
    total_loss = 0
    num_batches = 0
    
    is_parallel = isinstance(model, nn.DataParallel)
    actual_model = model.module if is_parallel else model
    
    for batch_data in tqdm(loader, desc="Training", leave=False):
        x, spatial_enc, y, y_text = batch_data
        x = x.to(device)
        spatial_enc = spatial_enc.to(device)
        y = y.to(device)
        
        st_features = None
        if st_encoder is not None:
            with torch.no_grad():
                st_features = st_encoder(x)
        
        try:
            loss = actual_model.forward_train(x, spatial_enc, st_features, y_text, instruction)
            
            if torch.isnan(loss) or torch.isinf(loss):
                print(f"\n⚠️ NaN/Inf detected in loss! Skipping batch...")
                continue
            
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
        except Exception as e:
            print(f"\n⚠️ Error in batch: {e}")
            continue
    
    return total_loss / max(num_batches, 1)


def validate(model, loader, device, st_encoder=None, instruction=None):
    model.eval()
    if st_encoder is not None:
        st_encoder.eval()
    
    total_mae = 0
    num_samples = 0
    parse_success = 0
    
    is_parallel = isinstance(model, nn.DataParallel)
    actual_model = model.module if is_parallel else model
    
    with torch.no_grad():
        for batch_data in tqdm(loader, desc="Validating", leave=False):
            x, spatial_enc, y, y_text = batch_data
            x = x.to(device)
            spatial_enc = spatial_enc.to(device)
            y = y.to(device)
            
            st_features = None
            if st_encoder is not None:
                st_features = st_encoder(x)
            
            try:
                generated_texts = actual_model.forward_generate(x, spatial_enc, st_features, instruction, max_new_tokens=100)
                
                for i, text in enumerate(generated_texts):
                    pred_values = parse_answer_text(text)
                    
                    if pred_values is not None:
                        pred_values = pred_values.to(device)
                        pred_values = torch.clamp(pred_values, 0.0, 1.0)
                        
                        mae = torch.abs(pred_values - y[i]).mean().item()
                        total_mae += mae
                        parse_success += 1
                    else:
                        pred_values = torch.full((12,), 0.5, device=device)
                        mae = torch.abs(pred_values - y[i]).mean().item()
                        total_mae += mae
                    
                    num_samples += 1
            except Exception as e:
                print(f"\n⚠️ Error in validation: {e}")
                batch_size = x.size(0)
                for i in range(batch_size):
                    pred_values = torch.full((12,), 0.5, device=device)
                    mae = torch.abs(pred_values - y[i]).mean().item()
                    total_mae += mae
                    num_samples += 1
    
    avg_mae = total_mae / max(num_samples, 1)
    return avg_mae


def set_seed(seed=42):
    """设置所有随机种子以保证可复现性"""
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"随机种子已设置: {seed}")


def main():
    print("="*60)
    print("Llama LoRA时空预测训练")
    print("="*60)
    
    # 设置随机种子
    set_seed(42)
    
    # 添加命令行参数解析
    parser = argparse.ArgumentParser(description='Llama LoRA时空预测训练')
    parser.add_argument('--csv_path', type=str, default='/data/wangyuehao/preflows/data/flow.csv',
                       help='数据CSV文件路径')
    parser.add_argument('--llama_model_path', type=str, 
                       default='/data/wangyuehao/preflows/meta-llama/Llama-3.2-1B',
                       help='Llama模型路径')
    parser.add_argument('--st_encoder_path', type=str,
                       default='/data/wangyuehao/preflows/urbangpt_style/best_model_time.pth',
                       help='ST Encoder模型路径')
    parser.add_argument('--output_dir', type=str,
                       default='/data/wangyuehao/preflows/urbangpt_style',
                       help='模型和结果保存目录')
    parser.add_argument('--gpu_ids', type=str, default='0',
                       help='使用的GPU ID，多个用逗号分隔，如: 0,1')
    parser.add_argument('--batch_size', type=int, default=64,
                       help='批次大小')
    parser.add_argument('--epochs', type=int, default=100,
                       help='训练轮数')
    parser.add_argument('--learning_rate', type=float, default=0.0001,
                       help='学习率')
    
    args = parser.parse_args()
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    config = {
        'csv_path': args.csv_path,
        'llama_model_path': args.llama_model_path,
        'st_encoder_path': args.st_encoder_path,
        'output_dir': args.output_dir,
        'lookback': 12,
        'predict': 12,
        'train_ratio': 0.8,
        'val_ratio': 0.1,
        'st_hidden_dim': 1024,  
        'st_num_layers': 8,      
        'st_dropout': 0.06,      
        'adj_threshold': 0.7,
        'adj_method': 'cosine',
        'gcn_dim': 16,
        'spatial_dim': 16,
        'lora_r': 16,
        'lora_alpha': 32,
        'lora_dropout': 0.1,
        'batch_size': args.batch_size,
        'learning_rate': args.learning_rate,
        'epochs': args.epochs,
        'patience': 3,
        'instruction': "Predict the next 12 time steps of traffic flow based on historical data and spatial context.",
        'device': 'cuda',
        'gpu_ids': [int(x) for x in args.gpu_ids.split(',')],
        'num_workers': 4,
    }
    
    print(f"\n配置信息:")
    print(f"  数据路径: {config['csv_path']}")
    print(f"  Llama模型: {config['llama_model_path']}")
    print(f"  ST Encoder: {config['st_encoder_path']}")
    print(f"  输出目录: {config['output_dir']}")
    print(f"  GPU IDs: {config['gpu_ids']}")
    
    os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(map(str, config['gpu_ids']))
    device = torch.device(config['device'])
    
    print(f"\n加载数据...")
    data = pd.read_csv(config['csv_path'], header=None).values
    print(f"数据形状: {data.shape}")
    num_nodes = data.shape[1]
    
    adj_matrix = construct_adjacency_matrix(
        data, 
        threshold=config['adj_threshold'],
        method=config['adj_method']
    )
    
    from scipy.ndimage import uniform_filter1d
    from sklearn.preprocessing import MinMaxScaler
    
    # 打印原始数据统计信息（用于诊断）
    print(f"\n原始数据统计:")
    print(f"  最小值: {data.min():.2f}")
    print(f"  最大值: {data.max():.2f}")
    print(f"  均值: {data.mean():.2f}")
    print(f"  标准差: {data.std():.2f}")
    
    data = uniform_filter1d(data, size=3, axis=0, mode='nearest')
    scaler = MinMaxScaler(feature_range=(0, 1))
    data_normalized = scaler.fit_transform(data)
    
    # 保存scaler，用于后续测试时的反归一化
    scaler_path = os.path.join(config['output_dir'], 'scaler.pkl')
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)
    print(f"\nScaler已保存: {scaler_path}")
    print(f"  数据范围 (data_range_): min={scaler.data_range_.min():.2f}, max={scaler.data_range_.max():.2f}")
    print(f"  平均数据范围: {scaler.data_range_.mean():.2f}")
    print(f"  ⚠️ 注意: 实际MAE = 归一化MAE × {scaler.data_range_.mean():.2f}")
    
    num_timesteps = data.shape[0]
    train_end = int(num_timesteps * config['train_ratio'])
    val_end = int(num_timesteps * (config['train_ratio'] + config['val_ratio']))
    
    train_data = data_normalized[:train_end]
    val_data = data_normalized[train_end:val_end]
    test_data = data_normalized[val_end:]
    
    print(f"训练/验证/测试: {train_data.shape[0]}/{val_data.shape[0]}/{test_data.shape[0]}")
    
    node_features = compute_node_features(train_data)
    gcn_embeddings = precompute_gcn_embeddings(
        adj_matrix, 
        node_features,
        gcn_output_dim=config['gcn_dim'],
        device=device
    )
    
    train_dataset = FlowDataset(train_data, gcn_embeddings=gcn_embeddings, 
                               lookback=config['lookback'], predict=config['predict'])
    val_dataset = FlowDataset(val_data, gcn_embeddings=gcn_embeddings,
                             lookback=config['lookback'], predict=config['predict'])
    test_dataset = FlowDataset(test_data, gcn_embeddings=gcn_embeddings,
                              lookback=config['lookback'], predict=config['predict'])
    
    train_loader = DataLoader(train_dataset, batch_size=config['batch_size'],
                             shuffle=True, num_workers=config['num_workers'], pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=config['batch_size'],
                           shuffle=False, num_workers=config['num_workers'], pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=config['batch_size'],
                            shuffle=False, num_workers=config['num_workers'], pin_memory=True)
    
    print("\n加载ST Encoder...")
    st_encoder = STEncoder(
        hidden_dim=config['st_hidden_dim'],
        num_layers=config['st_num_layers'],
        dropout=config['st_dropout'],
        lookback=config['lookback']
    ).to(device)
    
    st_encoder_loaded = False
    try:
        if os.path.exists(config['st_encoder_path']):
            st_encoder.load_state_dict(torch.load(config['st_encoder_path']))
            st_encoder.eval()
            for param in st_encoder.parameters():
                param.requires_grad = False
            print(f"✅ ST Encoder已加载并冻结: {config['st_encoder_path']}")
            st_encoder_loaded = True
        else:
            print(f"❌ ST Encoder文件不存在: {config['st_encoder_path']}")
            print(f"⚠️ 将使用随机初始化的ST Encoder（性能会很差！）")
            st_encoder = None
    except Exception as e:
        print(f"❌ ST Encoder加载失败: {e}")
        print(f"⚠️ 将使用随机初始化的ST Encoder（性能会很差！）")
        st_encoder = None
    
    if not st_encoder_loaded:
        print(f"\n{'='*60}")
        print(f"警告: ST Encoder未正确加载!")
        print(f"这会导致MAE非常高（可能>100）")
        print(f"请确保ST Encoder路径正确: {config['st_encoder_path']}")
        print(f"{'='*60}\n")
    
    print("\n创建Llama LoRA模型...")
    model = LlamaLoRAPredictor(
        llama_model_path=config['llama_model_path'],
        st_hidden_dim=config['st_hidden_dim'],
        spatial_dim=config['spatial_dim'],
        lora_r=config['lora_r'],
        lora_alpha=config['lora_alpha'],
        dropout=config['lora_dropout']
    )
    
    use_multi_gpu = len(config['gpu_ids']) > 1
    if use_multi_gpu and torch.cuda.device_count() > 1:
        model = nn.DataParallel(model, device_ids=config['gpu_ids'])
        if st_encoder is not None:
            st_encoder = nn.DataParallel(st_encoder, device_ids=config['gpu_ids'])
    
    model = model.to(device)
    if st_encoder is not None and not isinstance(st_encoder, nn.DataParallel):
        st_encoder = st_encoder.to(device)
    
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"参数: {trainable_params / 1e6:.1f}M / {total_params / 1e9:.2f}B (可训练/总)")
    
    optimizer = optim.AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=config['learning_rate'],
        weight_decay=1e-5
    )
    
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=10, T_mult=2, eta_min=1e-6
    )
    
    print("\n开始训练...")
    print("="*60)
    
    best_val_mae = float('inf')
    patience_counter = 0
    start_time = time.time()
    
    for epoch in range(config['epochs']):
        epoch_start = time.time()
        
        train_loss = train_epoch(model, train_loader, optimizer, device, 
                                st_encoder, config['instruction'])
        
        val_mae = validate(model, val_loader, device, 
                          st_encoder, config['instruction'])
        
        scheduler.step()
        
        epoch_time = time.time() - epoch_start
        
        print(f"Epoch {epoch+1:3d}/{config['epochs']} | "
              f"Train Loss: {train_loss:6.4f} | "
              f"Val MAE: {val_mae:6.4f} | "
              f"LR: {optimizer.param_groups[0]['lr']:.6f} | "
              f"Time: {epoch_time:.1f}s")
        
        if val_mae < best_val_mae:
            best_val_mae = val_mae
            patience_counter = 0
            
            model_save_path = os.path.join(config['output_dir'], 'llama_lora_model.pth')
            if isinstance(model, nn.DataParallel):
                torch.save(model.module.state_dict(), model_save_path)
            else:
                torch.save(model.state_dict(), model_save_path)
            
            print(f"   ✅ 最佳模型! Val MAE: {val_mae:.4f}")
            print(f"   模型已保存: {model_save_path}")
        else:
            patience_counter += 1
        
        if patience_counter >= config['patience']:
            print(f"\n⚠️  早停触发 (patience={config['patience']})")
            break
    
    total_time = time.time() - start_time
    print("="*60)
    print(f"训练完成! 耗时: {total_time/60:.1f} 分钟")
    
    print("\n测试集评估...")
    model_save_path = os.path.join(config['output_dir'], 'llama_lora_model.pth')
    if isinstance(model, nn.DataParallel):
        model.module.load_state_dict(torch.load(model_save_path))
    else:
        model.load_state_dict(torch.load(model_save_path))
    
    test_mae = validate(model, test_loader, device, st_encoder, config['instruction'])
    
    data_range = scaler.data_range_.mean()
    actual_test_mae = test_mae * data_range
    
    print(f"\n" + "="*60)
    print(f"测试集结果:")
    print(f"  归一化 MAE: {test_mae:.4f} (0-1范围内)")
    print(f"  实际 MAE: {actual_test_mae:.3f}")
    print(f"  Scaler数据范围: {data_range:.2f}")
    print(f"  计算公式: {test_mae:.4f} × {data_range:.2f} = {actual_test_mae:.3f}")
    print(f"="*60)
    
    # 诊断信息
    if actual_test_mae > 100:
        print(f"\n⚠️ 警告: 实际MAE过高 ({actual_test_mae:.3f})!")
        print(f"可能原因:")
        print(f"  1. 数据文件不同（检查原始数据统计）")
        print(f"  2. Scaler范围异常（data_range={data_range:.2f}）")
        print(f"  3. ST Encoder未正确加载")
        print(f"  4. 模型未收敛")
    
    results = {
        'config': config,
        'best_val_mae': float(best_val_mae),
        'test_mae': float(test_mae),
        'actual_test_mae': float(actual_test_mae),
        'scaler_data_range_mean': float(data_range),
        'total_time_minutes': total_time / 60,
        'trainable_params': trainable_params,
        'total_params': total_params,
        'architecture': 'Llama LoRA Q&A Text Generation + Spatial Encoding'
    }
    
    results_path = os.path.join(config['output_dir'], 'llama_lora_results_qa.json')
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n结果已保存:")
    print(f"  模型: {model_save_path}")
    print(f"  Scaler: {scaler_path}")
    print(f"  结果: {results_path}")
    print("="*60)


if __name__ == "__main__":
    main()

