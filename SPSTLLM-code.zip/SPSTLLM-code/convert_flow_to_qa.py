#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convert PEMS-03.csv to Q&A conversation format
针对新数据 PEMS-03 的转换脚本
"""

import pandas as pd
import numpy as np
import json
from tqdm import tqdm
import os
import pickle
from scipy.ndimage import uniform_filter1d
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics.pairwise import cosine_similarity
from scipy.stats import pearsonr


def construct_adjacency_matrix(data, threshold=0.5, method='pearson'):
    """构建邻接矩阵（与训练代码一致）"""
    num_timesteps, num_nodes = data.shape
    adj_matrix = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    
    if method == 'pearson':
        for i in range(num_nodes):
            for j in range(i, num_nodes):
                if i == j:
                    adj_matrix[i, j] = 1.0
                else:
                    corr, _ = pearsonr(data[:, i], data[:, j])
                    corr = abs(corr)
                    if corr >= threshold:
                        adj_matrix[i, j] = corr
                        adj_matrix[j, i] = corr
    
    elif method == 'cosine':
        similarity_matrix = cosine_similarity(data.T)
        adj_matrix = np.where(similarity_matrix >= threshold, similarity_matrix, 0)
        np.fill_diagonal(adj_matrix, 1.0)
    
    num_edges = (adj_matrix > 0).sum() - num_nodes
    print(f"  邻接矩阵: {adj_matrix.shape}, 边数: {num_edges}")
    
    return adj_matrix


def format_flow_values(values):
    """Format flow values exactly as in training code"""
    return ', '.join([f"{v:.2f}" for v in values])


def create_qa_sample(node_id, x_values, y_values, sample_id, spatial_context):
    """Create a Q&A sample matching training code format"""
    
    question = (
        "Predict the next 12 time steps of traffic flow based on historical data and spatial context.\n"
        f"{spatial_context}"
    )
    
    y_str = format_flow_values(y_values)
    answer = f"The predicted traffic flow is: [{y_str}]"
    
    conversation = {
        "id": f"flow_node_{node_id}_sample_{sample_id}",
        "conversations": [
            {
                "from": "human",
                "value": question
            },
            {
                "from": "gpt",
                "value": answer
            }
        ]
    }
    
    return conversation


def convert_flow_to_qa(csv_path, output_dir, 
                      lookback=12, predict=12,
                      train_ratio=0.6, val_ratio=0.2,
                      adj_threshold=0.7, adj_method='cosine', adj_csv_path=None):
    """
    Convert flow.csv to Q&A format datasets (matching training code)
    """
    
    print("="*80)
    print("Converting PEMS-03.csv to Q&A conversation format")
    print("Format matches training code: llama_lora_clean_gru.py")
    print("="*80)
    
    # Load raw data
    print(f"\nLoading data from: {csv_path}")
    data_raw = pd.read_csv(csv_path, header=None).values
    print(f"原始数据形状: {data_raw.shape} (timesteps={data_raw.shape[0]}, nodes={data_raw.shape[1]})")
    print(f"原始数据范围: [{data_raw.min():.2f}, {data_raw.max():.2f}]")
    
    # 数据预处理
    print(f"\n预处理数据...")
    print(f"  原始数据统计:")
    print(f"    最小值: {data_raw.min():.2f}")
    print(f"    最大值: {data_raw.max():.2f}")
    print(f"    均值: {data_raw.mean():.2f}")
    print(f"    标准差: {data_raw.std():.2f}")
    
    # 平滑处理
    data_smoothed = uniform_filter1d(data_raw, size=3, axis=0, mode='nearest')
    
    # 归一化
    scaler = MinMaxScaler(feature_range=(0, 1))
    data_normalized = scaler.fit_transform(data_smoothed)
    
    print(f"  归一化后数据范围: [{data_normalized.min():.2f}, {data_normalized.max():.2f}]")
    
    num_timesteps, num_nodes = data_raw.shape
    
    # Calculate split points
    train_end = int(num_timesteps * train_ratio)
    val_end = int(num_timesteps * (train_ratio + val_ratio))
    
    print(f"\n数据划分:")
    print(f"  Train: 0 - {train_end} ({train_end} timesteps)")
    print(f"  Val:   {train_end} - {val_end} ({val_end - train_end} timesteps)")
    print(f"  Test:  {val_end} - {num_timesteps} ({num_timesteps - val_end} timesteps)")
    
    # 分割归一化后的数据
    train_data = data_normalized[:train_end]
    val_data = data_normalized[train_end:val_end]
    test_data = data_normalized[val_end:]
    
    print(f"  归一化数据形状: Train={train_data.shape}, Val={val_data.shape}, Test={test_data.shape}")
    
    # 构建/加载邻接矩阵
    print(f"\n构建邻接矩阵...")
    print(f"  阈值: {adj_threshold}")
    if adj_csv_path and os.path.exists(adj_csv_path):
        print(f"  从外部文件加载: {adj_csv_path}")
        adj_df = pd.read_csv(adj_csv_path, header=None)
        adj_raw = adj_df.values.astype(np.float32)
        r, c = adj_raw.shape
        
        # 检查是否是方阵
        if r != c:
            print(f"  ⚠️ 外部矩阵非方阵: {r}x{c}. 将自动裁剪为方阵以继续处理")
            if c == r + 1:
                adj_raw = adj_raw[:, 1:]
                r, c = adj_raw.shape
                print(f"    已去掉第一列，形状变为: {r}x{c}")
            elif r == c + 1:
                adj_raw = adj_raw[1:, :]
                r, c = adj_raw.shape
                print(f"    已去掉第一行，形状变为: {r}x{c}")
            if r != c:
                n = min(r, c)
                adj_raw = adj_raw[:n, :n]
                print(f"    已裁剪为左上角方阵: {n}x{n}")
        
        # 检查节点数是否匹配
        if adj_raw.shape[0] != num_nodes:
            print(f"  ⚠️ 邻接矩阵节点数 ({adj_raw.shape[0]}) 与流量数据节点数 ({num_nodes}) 不匹配!")
            print(f"     将使用相似度方法重新构建邻接矩阵")
            adj_matrix = construct_adjacency_matrix(
                data_raw,
                threshold=adj_threshold,
                method=adj_method
            )
        else:
            # 归一化到[0,1]
            adj_min = adj_raw.min()
            adj_max = adj_raw.max()
            if adj_max > adj_min:
                adj_norm = (adj_raw - adj_min) / (adj_max - adj_min)
            else:
                adj_norm = np.zeros_like(adj_raw, dtype=np.float32)
            # 阈值化为0/1
            adj_matrix = (adj_norm <= adj_threshold).astype(np.float32)
            # 对称化与自环
            adj_matrix = np.maximum(adj_matrix, adj_matrix.T)
            np.fill_diagonal(adj_matrix, 1.0)
            print(f"  邻接矩阵(文件): {adj_matrix.shape}，边数: {(adj_matrix>0).sum()-adj_matrix.shape[0]}")
    else:
        print(f"  使用相似度构造 (method={adj_method})")
        adj_matrix = construct_adjacency_matrix(
            data_raw,
            threshold=adj_threshold,
            method=adj_method
        )
    
    # 准备空间提示词
    spatial_contexts = []
    for node in range(num_nodes):
        neighbors = [
            (nbr, float(adj_matrix[node, nbr]))
            for nbr in range(num_nodes)
            if nbr != node and adj_matrix[node, nbr] >= adj_threshold
        ]
        neighbors.sort(key=lambda x: x[1], reverse=True)
        if neighbors:
            top_neighbors = neighbors[:5]
            neighbor_str = "; ".join([f"node {nbr} (sim={weight:.2f})" for nbr, weight in top_neighbors])
            context = (
                f"Node ID: {node}. Top spatial neighbors (similarity ≥ {adj_threshold:.2f}): {neighbor_str}."
            )
        else:
            context = (
                f"Node ID: {node}. No spatial neighbors above similarity threshold {adj_threshold:.2f}."
            )
        spatial_contexts.append(context)

    # Generate samples for each split
    train_samples = []
    val_samples = []
    test_samples = []
    
    sample_id = 0
    
    print("\n生成Q&A对话样本...")
    
    # Training set
    max_train_idx = train_end - lookback - predict + 1
    for t in tqdm(range(max_train_idx), desc="Train"):
        for node in range(num_nodes):
            x = train_data[t:t+lookback, node]
            y = train_data[t+lookback:t+lookback+predict, node]
            
            conv = create_qa_sample(
                node_id=node,
                x_values=x,
                y_values=y,
                sample_id=sample_id,
                spatial_context=spatial_contexts[node]
            )
            
            train_samples.append(conv)
            sample_id += 1
    
    # Validation set
    max_val_idx = val_data.shape[0] - lookback - predict + 1
    for t in tqdm(range(max_val_idx), desc="Val"):
        for node in range(num_nodes):
            x = val_data[t:t+lookback, node]
            y = val_data[t+lookback:t+lookback+predict, node]
            
            conv = create_qa_sample(
                node_id=node,
                x_values=x,
                y_values=y,
                sample_id=sample_id,
                spatial_context=spatial_contexts[node]
            )
            
            val_samples.append(conv)
            sample_id += 1
    
    # Test set
    max_test_idx = test_data.shape[0] - lookback - predict + 1
    for t in tqdm(range(max_test_idx), desc="Test"):
        for node in range(num_nodes):
            x = test_data[t:t+lookback, node]
            y = test_data[t+lookback:t+lookback+predict, node]
            
            conv = create_qa_sample(
                node_id=node,
                x_values=x,
                y_values=y,
                sample_id=sample_id,
                spatial_context=spatial_contexts[node]
            )
            
            test_samples.append(conv)
            sample_id += 1
    
    print(f"\nGenerated samples:")
    print(f"  Train: {len(train_samples)}")
    print(f"  Val:   {len(val_samples)}")
    print(f"  Test:  {len(test_samples)}")
    print(f"  Total: {len(train_samples) + len(val_samples) + len(test_samples)}")
    
    # Save to JSON files and preprocessed data
    os.makedirs(output_dir, exist_ok=True)
    
    train_path = os.path.join(output_dir, "flow_train.json")
    val_path = os.path.join(output_dir, "flow_val.json")
    test_path = os.path.join(output_dir, "flow_test.json")
    
    print(f"\n保存数据集...")
    
    with open(train_path, 'w', encoding='utf-8') as f:
        json.dump(train_samples, f, indent=2, ensure_ascii=False)
    print(f"  Train: {train_path}")
    
    with open(val_path, 'w', encoding='utf-8') as f:
        json.dump(val_samples, f, indent=2, ensure_ascii=False)
    print(f"  Val: {val_path}")
    
    with open(test_path, 'w', encoding='utf-8') as f:
        json.dump(test_samples, f, indent=2, ensure_ascii=False)
    print(f"  Test: {test_path}")
    
    # 保存预处理后的数据矩阵
    print(f"\n保存预处理数据...")
    
    np.save(os.path.join(output_dir, "data_raw.npy"), data_raw)
    print(f"  原始数据: {os.path.join(output_dir, 'data_raw.npy')}")
    
    np.save(os.path.join(output_dir, "data_train_normalized.npy"), train_data)
    np.save(os.path.join(output_dir, "data_val_normalized.npy"), val_data)
    np.save(os.path.join(output_dir, "data_test_normalized.npy"), test_data)
    print(f"  归一化数据: data_train/val/test_normalized.npy")
    
    # 保存完整的归一化数据（用于GRU预训练）
    np.save(os.path.join(output_dir, "data_normalized.npy"), data_normalized)
    print(f"  完整归一化数据: {os.path.join(output_dir, 'data_normalized.npy')}")
    
    # 保存scaler
    scaler_path = os.path.join(output_dir, "scaler.pkl")
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)
    print(f"  Scaler: {scaler_path}")
    
    # 保存邻接矩阵
    adj_path = os.path.join(output_dir, "adjacency_matrix.npy")
    np.save(adj_path, adj_matrix)
    print(f"  邻接矩阵: {adj_path}")
    
    # 保存数据集统计信息
    stats = {
        "raw_data_shape": list(data_raw.shape),
        "num_nodes": num_nodes,
        "num_timesteps": num_timesteps,
        "train_samples": len(train_samples),
        "val_samples": len(val_samples),
        "test_samples": len(test_samples),
        "lookback": lookback,
        "predict": predict,
        "train_ratio": train_ratio,
        "val_ratio": val_ratio,
        "adj_threshold": adj_threshold,
        "adj_method": adj_method,
        "data_min": float(data_raw.min()),
        "data_max": float(data_raw.max()),
        "data_mean": float(data_raw.mean()),
        "data_std": float(data_raw.std()),
    }
    
    stats_path = os.path.join(output_dir, "dataset_stats.json")
    with open(stats_path, 'w', encoding='utf-8') as f:
        json.dump(stats, f, indent=2)
    print(f"  统计信息: {stats_path}")
    
    print("\n" + "="*80)
    print("Conversion completed successfully!")
    print("="*80)
    
    # Print sample examples
    print("\nExample conversations:")
    print("\n[Training Sample #1]")
    print(json.dumps(train_samples[0], indent=2, ensure_ascii=False))


def main():
    config = {
        'csv_path': '/data/wangyuehao/preflows/urbangpt_new/data/PEMS-03.csv',
        'output_dir': '/data/wangyuehao/preflows/urbangpt_new/qa_data',
        'lookback': 12,
        'predict': 12,
        'train_ratio': 0.6,
        'val_ratio': 0.2,
        'adj_threshold': 0.7,
        'adj_method': 'cosine',
        'adj_csv_path': '/data/wangyuehao/preflows/urbangpt_new/data/PEMS03_matrix.csv',
    }
    
    convert_flow_to_qa(**config)
    
    print("\n" + "="*80)
    print("数据集格式:")
    print("  问题: 'Predict the next 12 time steps of traffic flow...'")
    print("  答案: 'The predicted traffic flow is: [num, num, ...]'")
    print("\n已保存的文件:")
    print("  - QA JSON文件: flow_train.json, flow_val.json, flow_test.json")
    print("  - 预处理数据矩阵: data_raw.npy, data_*_normalized.npy")
    print("  - Scaler: scaler.pkl")
    print("  - 邻接矩阵: adjacency_matrix.npy")
    print("\n训练代码现在可以直接使用这些文件!")
    print("="*80)


if __name__ == "__main__":
    main()
