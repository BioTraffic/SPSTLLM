#!/usr/bin/env python3

import os
os.environ['TOKENIZERS_PARALLELISM'] = 'false'

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
from tqdm import tqdm
import time
import re
import warnings
import pickle
import argparse
warnings.filterwarnings('ignore')


def construct_adjacency_matrix(data, threshold=0.5, method='pearson'):
    num_timesteps, num_nodes = data.shape
    adj_matrix = np.zeros((num_nodes, num_nodes), dtype=np.float32)

    if method == 'pearson':
        from scipy.stats import pearsonr
        for i in range(num_nodes):
            for j in range(i, num_nodes):
                if i == j:
                    adj_matrix[i, j] = 1.0
                else:
                    corr, _ = pearsonr(data[:, i], data[:, j])
                    corr = abs(corr)
                    if corr >= threshold:
                        adj_matrix[i, j] = corr
                        adj_matrix[j, i] = corr

    elif method == 'cosine':
        from sklearn.metrics.pairwise import cosine_similarity
        similarity_matrix = cosine_similarity(data.T)
        adj_matrix = np.where(similarity_matrix >= threshold, similarity_matrix, 0)

    num_edges = (adj_matrix > 0).sum() - num_nodes
    print(f"邻接矩阵: {adj_matrix.shape}, 边数: {num_edges}")

    return adj_matrix


class SimpleGCN(nn.Module):
    def __init__(self, input_dim=1, hidden_dim=32, output_dim=16, dropout=0.1):
        super().__init__()
        self.gc1 = nn.Linear(input_dim, hidden_dim)
        self.gc2 = nn.Linear(hidden_dim, output_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.ReLU()
        self.residual = nn.Linear(input_dim, output_dim) if input_dim != output_dim else nn.Identity()

    def forward(self, x, adj):
        adj = adj + torch.eye(adj.size(0), device=adj.device)
        rowsum = adj.sum(1)
        d_inv_sqrt = torch.pow(rowsum, -0.5)
        d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.
        d_mat_inv_sqrt = torch.diag(d_inv_sqrt)
        adj_normalized = d_mat_inv_sqrt @ adj @ d_mat_inv_sqrt

        h = self.gc1(adj_normalized @ x)
        h = self.activation(h)
        h = self.dropout(h)
        h = self.gc2(adj_normalized @ h)

        h = h + self.residual(x)
        return h


def compute_node_features(data):
    num_timesteps, num_nodes = data.shape
    features = []

    for i in range(num_nodes):
        node_data = data[:, i]
        features.append([
            node_data.mean(),
            node_data.std(),
            node_data.max(),
            node_data.min(),
            np.percentile(node_data, 75),
            np.percentile(node_data, 25),
            np.percentile(node_data, 90),
            np.percentile(node_data, 10),
            (node_data[-1] - node_data[0]) / len(node_data),
            np.mean(np.abs(np.diff(node_data))),
        ])

    node_features = np.array(features, dtype=np.float32)
    print(f"节点特征: {node_features.shape}")
    return node_features


def precompute_gcn_embeddings(adj_matrix, node_features, gcn_output_dim=16, device='cpu'):
    num_nodes, feature_dim = node_features.shape
    gcn = SimpleGCN(input_dim=feature_dim, hidden_dim=32, output_dim=gcn_output_dim).to(device)
    adj_tensor = torch.FloatTensor(adj_matrix).to(device)
    node_features_tensor = torch.FloatTensor(node_features).to(device)

    with torch.no_grad():
        node_embeddings = gcn(node_features_tensor, adj_tensor)

    print(f"GCN嵌入: {node_embeddings.shape}")
    return node_embeddings.cpu()


def format_answer_text(y_values):
    if isinstance(y_values, torch.Tensor):
        y_values = y_values.cpu().numpy()

    values_str = ', '.join([f"{v:.2f}" for v in y_values])
    answer_text = f"The predicted traffic flow is: [{values_str}]"

    return answer_text


def parse_answer_text(text):
    try:
        match = re.search(r'\[(.*?)\]', text)
        if match:
            content = match.group(1)
            numbers = [float(x.strip()) for x in content.split(',')]
            if len(numbers) == 12:
                return torch.tensor(numbers, dtype=torch.float32)
        return None
    except:
        return None


def compute_metrics(predictions, targets, scaler=None):
    predictions = predictions.detach().cpu().numpy()
    targets = targets.detach().cpu().numpy()

    mae = np.mean(np.abs(predictions - targets))

    rmse = np.sqrt(np.mean((predictions - targets) ** 2))

    if scaler is not None:
        data_range_mean = scaler.data_range_.mean()
        data_min_mean = scaler.data_min_.mean()
        predictions_denorm = predictions * data_range_mean + data_min_mean
        targets_denorm = targets * data_range_mean + data_min_mean
        epsilon = 1e-6
        denominator = np.abs(targets_denorm) + epsilon
        mape = np.mean(np.abs((predictions_denorm - targets_denorm) / denominator)) * 100
        mape = np.clip(mape, 0, 1000)
    else:
        epsilon = 1e-6
        denominator = np.abs(targets) + epsilon
        mape = np.mean(np.abs((predictions - targets) / denominator)) * 100
        mape = np.clip(mape, 0, 1000)

    return mae, rmse, mape


class FlowDataset(Dataset):
    def __init__(self, data, gcn_embeddings=None, lookback=12, predict=12):
        self.data = data
        self.gcn_embeddings = gcn_embeddings
        self.lookback = lookback
        self.predict = predict
        self.num_timesteps, self.num_nodes = data.shape

        self.samples = []
        max_idx = self.num_timesteps - lookback - predict + 1

        for t in range(max_idx):
            for node in range(self.num_nodes):
                self.samples.append((t, node))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        t, node = self.samples[idx]
        x = self.data[t:t+self.lookback, node]
        y = self.data[t+self.lookback:t+self.lookback+self.predict, node]

        if self.gcn_embeddings is not None:
            spatial_enc = self.gcn_embeddings[node]
        else:
            spatial_enc = torch.zeros(16, dtype=torch.float32)

        y_text = format_answer_text(y)

        # 返回元数据 (t, node)
        meta_info = torch.tensor([t, node], dtype=torch.long)
        return torch.FloatTensor(x), torch.FloatTensor(spatial_enc), torch.FloatTensor(y), y_text, meta_info


class FlowQADataset(Dataset):
    def __init__(self, json_path, data_matrix, neighbor_1hop, neighbor_2hop, multiscale,
                 gcn_embeddings, start_time_idx=0, lookback=12, predict=12):
        self.data_matrix = data_matrix
        self.neighbor_1hop = neighbor_1hop  # [T, N] 1阶邻居聚合
        self.neighbor_2hop = neighbor_2hop  # [T, N] 2阶邻居聚合
        self.multiscale = multiscale        # [T, N, 3] 多尺度特征
        self.gcn_embeddings = gcn_embeddings
        self.start_time_idx = start_time_idx
        self.lookback = lookback
        self.predict = predict
        self.num_timesteps, self.num_nodes = data_matrix.shape

        print(f"加载QA数据: {json_path}")
        with open(json_path, 'r') as f:
            raw_samples = json.load(f)
        print(f"  样本数: {len(raw_samples)}")
        
        # 只保存必要的 (node, sample_idx) 信息，立即释放原始 JSON 数据以节省内存
        self.sample_indices = []
        for item in raw_samples:
            item_id = item['id']
            parts = item_id.split('_')
            node = int(parts[2])
            sample_idx = int(parts[4])
            self.sample_indices.append((node, sample_idx))
        del raw_samples  # 释放原始 JSON 数据
        
        # 预计算 samples_per_node 用于计算 t
        self.samples_per_node = self.num_timesteps - lookback - predict + 1

        # 预计算时间特征 [T + lookback, 6]
        # 我们需要覆盖从 start_time_idx 开始的所有可能时间步
        # 注意：__getitem__ 中使用的是 global_time_idx = self.start_time_idx + t + i
        # 最大 t 为 self.num_timesteps - lookback - predict
        # 最大 i 为 lookback - 1
        # 因此最大时间索引覆盖到 num_timesteps 即可
        print("预计算时间特征...")
        total_time_steps = self.num_timesteps + lookback # 多预留一些buffer
        self.time_features_cache = np.zeros((total_time_steps, 6), dtype=np.float32)
        
        # 矢量化计算时间特征
        time_indices = np.arange(self.start_time_idx, self.start_time_idx + total_time_steps)
        minutes = time_indices * 5
        hours = (minutes // 60) % 24
        day_of_weeks = (time_indices // 288) % 7
        
        self.time_features_cache[:, 0] = np.sin(2 * np.pi * hours / 24)
        self.time_features_cache[:, 1] = np.cos(2 * np.pi * hours / 24)
        self.time_features_cache[:, 2] = np.sin(2 * np.pi * day_of_weeks / 7)
        self.time_features_cache[:, 3] = np.cos(2 * np.pi * day_of_weeks / 7)
        # hour in [7, 8, 9, 17, 18, 19]
        self.time_features_cache[:, 4] = np.isin(hours, [7, 8, 9, 17, 18, 19]).astype(np.float32)
        # day_of_week >= 5
        self.time_features_cache[:, 5] = (day_of_weeks >= 5).astype(np.float32)

    def __len__(self):
        return len(self.sample_indices)

    def __getitem__(self, idx):
        node, sample_idx = self.sample_indices[idx]
        t = sample_idx % self.samples_per_node

        # 使用 numpy 切片代替 copy()，如果后续没有原地修改操作，可以不copy，但为了安全还是保留copy
        # 不过对于 time_features，我们直接切片即可，它是只读的
        
        x = self.data_matrix[t:t+self.lookback, node]
        y = self.data_matrix[t+self.lookback:t+self.lookback+self.predict, node]

        # 邻居聚合特征
        n1 = self.neighbor_1hop[t:t+self.lookback, node]
        n2 = self.neighbor_2hop[t:t+self.lookback, node]
        
        # 多尺度特征 [lookback, 3]
        ms = self.multiscale[t:t+self.lookback, node, :]
        
        # 时间特征 [lookback, 6] - 直接切片
        # global_time_idx 从 self.start_time_idx + t 开始
        # cache 索引 0 对应 self.start_time_idx
        # 所以 cache 索引为 t 到 t + lookback
        time_features = self.time_features_cache[t : t+self.lookback]

        if self.gcn_embeddings is not None and node < len(self.gcn_embeddings):
            spatial_enc = self.gcn_embeddings[node]
        else:
            spatial_enc = torch.zeros(16, dtype=torch.float32)

        y_text = format_answer_text(y)

        # 返回元数据 (t, node)
        meta_info = torch.tensor([t, node], dtype=torch.long)
        
        # 注意：这里去掉了 .copy() 以减少内存分配，如果下游没有修改这些tensor的操作，这是安全的。
        # 并且转换为 Tensor 时会自动处理内存布局
        return (torch.FloatTensor(x), 
                torch.FloatTensor(n1),
                torch.FloatTensor(n2),
                torch.FloatTensor(ms),
                torch.FloatTensor(time_features),
                torch.FloatTensor(spatial_enc), 
                torch.FloatTensor(y), 
                y_text, 
                meta_info)


class GRUEncoder(nn.Module):
    """GRU Encoder 与 gru_with_time_features.py 中的 FlowPredictorWithGRU 对齐"""
    def __init__(self, hidden_channels=1024, num_layers=8, dropout=0.06, lookback=12, out_dim=1024):
        super().__init__()
        self.hidden_dim = hidden_channels
        self.num_layers = num_layers
        self.lookback = lookback

        self.pos_encoding = nn.Parameter(torch.randn(1, lookback, 24))

        # 自身流量(1) + 1阶邻居(1) + 2阶邻居(1) + 多尺度(3) + 位置编码(24) + 统计量(4) + 时间特征(6)
        self.feature_dim = 1 + 1 + 1 + 3 + 24 + 4 + 6  # = 40

        self.gru = nn.GRU(
            input_size=self.feature_dim,
            hidden_size=hidden_channels // 2,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=True
        )

        self.layer_norm = nn.LayerNorm(hidden_channels)

        self.attention = nn.Sequential(
            nn.Linear(hidden_channels, hidden_channels // 2),
            nn.Tanh(),
            nn.Linear(hidden_channels // 2, 1)
        )

        self.head = nn.Linear(hidden_channels, out_dim)

    def forward(self, x, neighbor_1hop, neighbor_2hop, multiscale, time_features):
        """
        x: [batch, lookback] 原始流量
        neighbor_1hop: [batch, lookback] 1阶邻居聚合特征
        neighbor_2hop: [batch, lookback] 2阶邻居聚合特征
        multiscale: [batch, lookback, 3] 多尺度特征 (day_diff, week_diff, trend)
        time_features: [batch, lookback, 6] 时间特征
        """
        batch_size = x.size(0)
        device = x.device

        x_feat = x.unsqueeze(-1)
        neighbor_1hop_feat = neighbor_1hop.unsqueeze(-1)
        neighbor_2hop_feat = neighbor_2hop.unsqueeze(-1)
        pos_enc = self.pos_encoding.expand(batch_size, -1, -1)

        mean = x.mean(dim=1, keepdim=True).unsqueeze(-1).expand(-1, self.lookback, 1)
        std = x.std(dim=1, keepdim=True).unsqueeze(-1).expand(-1, self.lookback, 1) + 1e-6
        max_val = x.max(dim=1, keepdim=True)[0].unsqueeze(-1).expand(-1, self.lookback, 1)
        min_val = x.min(dim=1, keepdim=True)[0].unsqueeze(-1).expand(-1, self.lookback, 1)

        x_enhanced = torch.cat([x_feat, neighbor_1hop_feat, neighbor_2hop_feat, multiscale,
                                pos_enc, mean, std, max_val, min_val, time_features], dim=-1)

        gru_out, _ = self.gru(x_enhanced)
        gru_out = self.layer_norm(gru_out)

        attn_scores = self.attention(gru_out)
        attn_weights = torch.softmax(attn_scores, dim=1)
        context = (gru_out * attn_weights).sum(dim=1)

        output = self.head(context)
        return output


class LlamaLoRAPredictor(nn.Module):
    def __init__(self, llama_model_path, st_hidden_dim=1024, spatial_dim=16,
                 lora_r=16, lora_alpha=32, dropout=0.1):
        super().__init__()

        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.tokenizer = AutoTokenizer.from_pretrained(llama_model_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.llama = AutoModelForCausalLM.from_pretrained(
            llama_model_path,
            torch_dtype=torch.bfloat16,
            device_map=None,
            low_cpu_mem_usage=True
        )

        self.hidden_size = self.llama.config.hidden_size

        from peft import LoraConfig, get_peft_model, TaskType

        lora_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=dropout,
            target_modules=["q_proj", "v_proj"],
            bias="none",
        )

        self.llama = get_peft_model(self.llama, lora_config)
        self.llama.print_trainable_parameters()

        self.st_projector = nn.Sequential(
            nn.Linear(st_hidden_dim, 1024),
            nn.LayerNorm(1024),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(1024, self.hidden_size),
            nn.LayerNorm(self.hidden_size)
        )

        self.spatial_projector = nn.Sequential(
            nn.Linear(spatial_dim, 128),
            nn.LayerNorm(128),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(128, self.hidden_size),
            nn.LayerNorm(self.hidden_size)
        )

        self._init_weights()

        # 缓存 instruction tokens
        self.cached_instruction_tokens = None

    def _init_weights(self):
        for module in [self.st_projector, self.spatial_projector]:
            for m in module.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight, gain=0.01)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)

    def forward(self, x, spatial_enc, st_features=None, answer_input_ids=None, instruction=None, mode='train', **kwargs):
        if mode == 'train':
            return self.forward_train(x, spatial_enc, st_features, answer_input_ids, instruction)
        elif mode == 'generate':
            return self.forward_generate(x, spatial_enc, st_features, instruction, **kwargs)
        else:
            raise ValueError(f"Unknown mode: {mode}")

    def forward_train(self, x, spatial_enc, st_features, answer_input_ids, instruction=None):
        batch_size = x.size(0)
        device = x.device

        if instruction is None:
            instruction = "Predict the next 12 time steps of traffic flow based on historical data and spatial context."
            
            # 使用缓存
            if self.cached_instruction_tokens is None:
                self.cached_instruction_tokens = self.tokenizer(
                    instruction,
                    return_tensors='pt',
                    padding=False, # 单个句子不需要padding
                    truncation=True,
                    max_length=64
                )['input_ids'].to(device) # [1, seq_len]
            
            # 扩展 batch
            question_input_ids = self.cached_instruction_tokens.expand(batch_size, -1)
        else:
            # 动态 instruction (如果有的话)
            question_tokens = self.tokenizer(
                [instruction] * batch_size,
                return_tensors='pt',
                padding=True,
                truncation=True,
                max_length=64
            ).to(device)
            question_input_ids = question_tokens['input_ids']

        question_embs = self.llama.get_base_model().model.embed_tokens(question_input_ids)

        if st_features is not None:
            st_embs = self.st_projector(st_features.to(torch.float32))
            st_embs = st_embs.unsqueeze(1).to(torch.bfloat16)
        else:
            st_embs = torch.zeros(batch_size, 1, self.hidden_size,
                                 dtype=torch.bfloat16, device=device)

        spatial_embs = self.spatial_projector(spatial_enc.to(torch.float32))
        spatial_embs = spatial_embs.unsqueeze(1).to(torch.bfloat16)

        flow_tokens = (x * 1000).long() + 5000
        flow_tokens = torch.clamp(flow_tokens, 0, self.tokenizer.vocab_size - 1)
        flow_embs = self.llama.get_base_model().model.embed_tokens(flow_tokens)

        # answer_input_ids 已经是 tensor，不需要在这里 tokenize
        answer_embs = self.llama.get_base_model().model.embed_tokens(
            answer_input_ids
        )

        combined_embs = torch.cat([
            question_embs,
            st_embs,
            spatial_embs,
            flow_embs,
            answer_embs
        ], dim=1)

        q_len = question_input_ids.size(1)
        st_len = st_embs.size(1)
        spatial_len = spatial_embs.size(1)
        flow_len = flow_embs.size(1)
        a_len = answer_input_ids.size(1)
        total_len = combined_embs.size(1)

        attention_mask = torch.ones(batch_size, total_len, device=device)
        labels = torch.full((batch_size, total_len), -100, dtype=torch.long, device=device)
        answer_start = q_len + st_len + spatial_len + flow_len
        labels[:, answer_start:answer_start+a_len] = answer_input_ids

        outputs = self.llama(
            inputs_embeds=combined_embs,
            attention_mask=attention_mask,
            labels=labels,
            return_dict=True
        )

        return outputs.loss

    def forward_generate(self, x, spatial_enc, st_features, instruction=None, max_new_tokens=100):
        batch_size = x.size(0)
        device = x.device

        if instruction is None:
            instruction = "Predict the next 12 time steps of traffic flow based on historical data and spatial context."

        question_tokens = self.tokenizer(
            [instruction] * batch_size,
            return_tensors='pt',
            padding=True,
            truncation=True,
            max_length=64
        ).to(device)

        question_embs = self.llama.get_base_model().model.embed_tokens(
            question_tokens['input_ids']
        )

        if st_features is not None:
            st_embs = self.st_projector(st_features.to(torch.float32))
            st_embs = st_embs.unsqueeze(1).to(torch.bfloat16)
        else:
            st_embs = torch.zeros(batch_size, 1, self.hidden_size,
                                 dtype=torch.bfloat16, device=device)

        spatial_embs = self.spatial_projector(spatial_enc.to(torch.float32))
        spatial_embs = spatial_embs.unsqueeze(1).to(torch.bfloat16)

        flow_tokens = (x * 1000).long() + 5000
        flow_tokens = torch.clamp(flow_tokens, 0, self.tokenizer.vocab_size - 1)
        flow_embs = self.llama.get_base_model().model.embed_tokens(flow_tokens)

        combined_embs = torch.cat([
            question_embs,
            st_embs,
            spatial_embs,
            flow_embs
        ], dim=1)

        attention_mask = torch.ones(batch_size, combined_embs.size(1), device=device)

        with torch.no_grad():
            outputs = self.llama.generate(
                inputs_embeds=combined_embs,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                temperature=1.0,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )

        generated_texts = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)

        return generated_texts


def train_epoch(model, loader, optimizer, device, st_encoder=None, instruction=None):
    """训练一轮"""
    model.train()
    if st_encoder is not None:
        st_encoder.eval()

    total_loss = 0
    num_batches = 0
    
    for batch_data in tqdm(loader, desc="Training", leave=False):
        # 解包新的数据格式
        x, n1, n2, ms, time_feat, spatial_enc, y, y_text, _ = batch_data
        x = x.to(device)
        n1 = n1.to(device)
        n2 = n2.to(device)
        ms = ms.to(device)
        time_feat = time_feat.to(device)
        spatial_enc = spatial_enc.to(device)
        y = y.to(device)

        st_features = None
        if st_encoder is not None:
            with torch.no_grad():
                st_features = st_encoder(x, n1, n2, ms, time_feat)

        try:
            # 预处理 y_text
            answer_tokens = model.tokenizer(
                y_text,
                return_tensors='pt',
                padding=True,
                truncation=True,
                max_length=128
            ).to(device)
            answer_input_ids = answer_tokens['input_ids']

            loss = model(x, spatial_enc, st_features, answer_input_ids=answer_input_ids, instruction=instruction, mode='train')

            if loss.ndim > 0:
                loss = loss.mean()

            if torch.isnan(loss) or torch.isinf(loss):
                print(f"\n⚠️ NaN/Inf detected in loss! Skipping batch...")
                continue

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            total_loss += loss.item()
            num_batches += 1
        except Exception as e:
            print(f"\n⚠️ Error in batch: {e}")
            continue

    return total_loss / max(num_batches, 1)


def evaluate_and_collect_stats(model, loader, device, st_encoder, instruction, scaler, config, test_data_shape):
    """
    统一的评估函数：
    1. 计算整体指标 (MAE, RMSE, MAPE)
    2. 收集 per-horizon 指标
    3. 重建时间序列用于绘图
    """
    model.eval()
    if st_encoder is not None:
        st_encoder.eval()

    # 整体指标
    total_mae = 0
    total_rmse = 0
    total_mape = 0
    num_samples = 0
    
    # 详细指标配置
    horizon = config['predict']
    num_timesteps, num_nodes = test_data_shape
    
    # Per-horizon 统计
    mae_per_h = np.zeros(horizon)
    rmse_per_h = np.zeros(horizon)
    mape_per_h = np.zeros(horizon)
    count_per_h = np.zeros(horizon)
    
    # 时间序列重建
    pred_series = np.zeros((num_timesteps, num_nodes), dtype=np.float32)
    pred_counts = np.zeros((num_timesteps, num_nodes), dtype=np.float32)

    with torch.no_grad():
        for batch_data in tqdm(loader, desc="评估 & 数据收集"):
            # 解包数据
            x, n1, n2, ms, time_feat, spatial_enc, y, y_text, meta_info = batch_data
            x = x.to(device)
            n1 = n1.to(device)
            n2 = n2.to(device)
            ms = ms.to(device)
            time_feat = time_feat.to(device)
            spatial_enc = spatial_enc.to(device)
            y = y.to(device)
            meta_info = meta_info.cpu().numpy()

            st_features = None
            if st_encoder is not None:
                st_features = st_encoder(x, n1, n2, ms, time_feat)

            try:
                # 生成预测文本
                generated_texts = model.forward_generate(x, spatial_enc, st_features, instruction, max_new_tokens=100)

                for i, text in enumerate(generated_texts):
                    pred_values = parse_answer_text(text)

                    if pred_values is not None:
                        pred_values = pred_values.to(device)
                        pred_values = torch.clamp(pred_values, 0.0, 1.0)
                    else:
                        pred_values = torch.full((horizon,), 0.5, device=device)

                    # --- 1. 整体指标累积 ---
                    mae, rmse, mape = compute_metrics(pred_values, y[i], scaler)
                    total_mae += mae
                    total_rmse += rmse
                    total_mape += mape
                    num_samples += 1

                    # --- 2. Per-horizon & 时间序列数据 ---
                    pv_np = pred_values.cpu().numpy()
                    y_np = y[i].cpu().numpy()
                    
                    # 按 horizon 统计
                    for h in range(horizon):
                        diff = np.abs(pv_np[h] - y_np[h])
                        mae_per_h[h] += diff
                        rmse_per_h[h] += diff ** 2
                        if np.abs(y_np[h]) > 1e-6:
                            mape_per_h[h] += np.abs((pv_np[h] - y_np[h]) / y_np[h])
                        count_per_h[h] += 1
                    
                    # 重建时间序列
                    t_idx, node_idx = meta_info[i]
                    for h in range(horizon):
                        time_idx = t_idx + config['lookback'] + h
                        if 0 <= time_idx < num_timesteps:
                            pred_series[time_idx, node_idx] += pv_np[h]
                            pred_counts[time_idx, node_idx] += 1

            except Exception as e:
                print(f"\n⚠️ Error in batch evaluation: {e}")
                continue

    # 整理结果
    overall_metrics = (
        total_mae / max(num_samples, 1),
        total_rmse / max(num_samples, 1),
        total_mape / max(num_samples, 1)
    )
    
    # 整理 Per-horizon
    mae_per_h /= np.maximum(count_per_h, 1)
    rmse_per_h = np.sqrt(rmse_per_h / np.maximum(count_per_h, 1))
    mape_per_h = 100 * mape_per_h / np.maximum(count_per_h, 1)
    
    detailed_stats = {
        'mae_per_h': mae_per_h,
        'rmse_per_h': rmse_per_h,
        'mape_per_h': mape_per_h,
        'pred_series': pred_series,
        'pred_counts': pred_counts
    }
    
    return overall_metrics, detailed_stats



def evaluate_and_collect_stats_ddp(model, loader, device, st_encoder, instruction, scaler, config, test_data_shape, is_main=True):
    model.eval()
    if st_encoder is not None:
        st_encoder.eval()

    horizon = config['predict']
    num_timesteps, num_nodes = test_data_shape

    mae_sum = 0.0
    rmse_sum = 0.0
    mape_sum = 0.0
    sample_count = 0.0

    mae_per_h = np.zeros(horizon, dtype=np.float32)
    rmse_per_h = np.zeros(horizon, dtype=np.float32)
    mape_per_h = np.zeros(horizon, dtype=np.float32)
    count_per_h = np.zeros(horizon, dtype=np.float32)

    pred_series = np.zeros((num_timesteps, num_nodes), dtype=np.float32)
    pred_counts = np.zeros((num_timesteps, num_nodes), dtype=np.float32)

    loader_iter = tqdm(loader, desc="评估 & 数据收集", disable=not is_main)

    with torch.no_grad():
        for batch_data in loader_iter:
            x, n1, n2, ms, time_feat, spatial_enc, y, y_text, meta_info = batch_data
            x = x.to(device)
            n1 = n1.to(device)
            n2 = n2.to(device)
            ms = ms.to(device)
            time_feat = time_feat.to(device)
            spatial_enc = spatial_enc.to(device)
            y = y.to(device)
            meta_info = meta_info.cpu().numpy()

            st_features = None
            if st_encoder is not None:
                st_features = st_encoder(x, n1, n2, ms, time_feat)

            try:
                generated_texts = model.forward_generate(x, spatial_enc, st_features, instruction, max_new_tokens=100)

                for i, text in enumerate(generated_texts):
                    pred_values = parse_answer_text(text)

                    if pred_values is not None:
                        pred_values = pred_values.to(device)
                        pred_values = torch.clamp(pred_values, 0.0, 1.0)
                    else:
                        pred_values = torch.full((horizon,), 0.5, device=device)

                    mae, rmse, mape = compute_metrics(pred_values, y[i], scaler)
                    mae_sum += mae
                    rmse_sum += rmse
                    mape_sum += mape
                    sample_count += 1.0

                    pv_np = pred_values.detach().cpu().numpy()
                    y_np = y[i].detach().cpu().numpy()

                    for h in range(horizon):
                        diff = np.abs(pv_np[h] - y_np[h])
                        mae_per_h[h] += diff
                        rmse_per_h[h] += diff ** 2
                        if np.abs(y_np[h]) > 1e-6:
                            mape_per_h[h] += np.abs((pv_np[h] - y_np[h]) / y_np[h])
                        count_per_h[h] += 1.0

                    t_idx, node_idx = meta_info[i]
                    for h in range(horizon):
                        time_idx = t_idx + config['lookback'] + h
                        if 0 <= time_idx < num_timesteps:
                            pred_series[time_idx, node_idx] += pv_np[h]
                            pred_counts[time_idx, node_idx] += 1.0

            except Exception as e:
                if is_main:
                    print(f"\n⚠️ Error in batch evaluation: {e}")
                continue

    metrics_vec = torch.tensor([mae_sum, rmse_sum, mape_sum, sample_count], device=device, dtype=torch.float32)
    if dist.is_initialized():
        dist.all_reduce(metrics_vec, op=dist.ReduceOp.SUM)

    total_mae, total_rmse, total_mape, total_count = metrics_vec.tolist()
    total_count = max(total_count, 1.0)

    mae_per_h_t = torch.from_numpy(mae_per_h).to(device)
    rmse_per_h_t = torch.from_numpy(rmse_per_h).to(device)
    mape_per_h_t = torch.from_numpy(mape_per_h).to(device)
    count_per_h_t = torch.from_numpy(count_per_h).to(device)

    if dist.is_initialized():
        dist.all_reduce(mae_per_h_t, op=dist.ReduceOp.SUM)
        dist.all_reduce(rmse_per_h_t, op=dist.ReduceOp.SUM)
        dist.all_reduce(mape_per_h_t, op=dist.ReduceOp.SUM)
        dist.all_reduce(count_per_h_t, op=dist.ReduceOp.SUM)

    count_clamped = torch.clamp(count_per_h_t, min=1.0)
    mae_per_h_final = (mae_per_h_t / count_clamped).cpu().numpy()
    rmse_per_h_final = torch.sqrt(rmse_per_h_t / count_clamped).cpu().numpy()
    mape_per_h_final = 100.0 * (mape_per_h_t / count_clamped).cpu().numpy()

    pred_series_t = torch.from_numpy(pred_series).to(device)
    pred_counts_t = torch.from_numpy(pred_counts).to(device)

    if dist.is_initialized():
        dist.all_reduce(pred_series_t, op=dist.ReduceOp.SUM)
        dist.all_reduce(pred_counts_t, op=dist.ReduceOp.SUM)

    pred_series_final = pred_series_t.cpu().numpy()
    pred_counts_final = pred_counts_t.cpu().numpy()

    overall_metrics = (
        total_mae / total_count,
        total_rmse / total_count,
        total_mape / total_count
    )

    detailed_stats = {
        'mae_per_h': mae_per_h_final,
        'rmse_per_h': rmse_per_h_final,
        'mape_per_h': mape_per_h_final,
        'pred_series': pred_series_final,
        'pred_counts': pred_counts_final
    }

    return overall_metrics, detailed_stats



def set_seed(seed=42, rank=0):
    """设置随机种子"""
    import random
    seed = seed + rank  # 每个进程使用不同的种子
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def setup_ddp(rank, world_size, master_port='12355'):
    """初始化 DDP 进程组"""
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = master_port
    dist.init_process_group("nccl", rank=rank, world_size=world_size)
    torch.cuda.set_device(rank)


def cleanup_ddp():
    """清理 DDP 进程组"""
    if dist.is_initialized():
        dist.destroy_process_group()


def is_main_process():
    """判断是否是主进程"""
    return not dist.is_initialized() or dist.get_rank() == 0


def main_worker(rank, world_size, gpu_ids, args):
    """每个 GPU 上运行的主函数"""
    # 设置当前进程使用的 GPU
    local_gpu_id = gpu_ids[rank]
    torch.cuda.set_device(local_gpu_id)
    device = torch.device(f'cuda:{local_gpu_id}')
    
    # 初始化 DDP
    if world_size > 1:
        os.environ['MASTER_ADDR'] = 'localhost'
        os.environ['MASTER_PORT'] = args.master_port
        dist.init_process_group("nccl", rank=rank, world_size=world_size)
    
    set_seed(42, rank)
    
    is_main = (rank == 0)
    
    config = {
        'qa_data_dir': args.qa_data_dir,
        'llama_model_path': args.llama_model_path,
        'st_encoder_path': args.st_encoder_path,
        'output_dir': args.output_dir,
        'lookback': 12,
        'predict': 12,
        'train_ratio': 0.6,
        'val_ratio': 0.2,
        'st_hidden_dim': 1024,
        'st_num_layers': 8,
        'st_dropout': 0.06,
        'gcn_dim': 16,
        'spatial_dim': 16,
        'lora_r': 16,
        'lora_alpha': 32,
        'lora_dropout': 0.1,
        'batch_size': args.batch_size,
        'learning_rate': args.learning_rate,
        'epochs': args.epochs,
        'patience': 3,
        'instruction': "Predict the next 12 time steps of traffic flow based on historical data and spatial context.",
        'device': 'cuda',
        'num_workers': 4,
        'world_size': world_size,
        'rank': rank,
    }
    
    if is_main:
        print(f"\n配置信息:")
        print(f"  QA数据目录: {args.qa_data_dir}")
        print(f"  Llama模型: {config['llama_model_path']}")
        print(f"  ST Encoder: {config['st_encoder_path']} (GRU版本)")
        print(f"  输出目录: {config['output_dir']}")
        print(f"  使用GPU: {gpu_ids} (共 {world_size} 卡)")
        print(f"  每卡Batch Size: {config['batch_size']}, 总有效Batch Size: {config['batch_size'] * world_size}")

    # 加载数据
    required_files = [
        'data_train_normalized.npy',
        'data_val_normalized.npy',
        'data_test_normalized.npy',
        'scaler.pkl',
        'adjacency_matrix.npy'
    ]
    missing = [f for f in required_files if not os.path.exists(os.path.join(args.qa_data_dir, f))]
    if missing:
        raise FileNotFoundError("缺少必需文件:\n" + "\n".join(f"  - {os.path.join(args.qa_data_dir, f)}" for f in missing))

    train_data = np.load(os.path.join(args.qa_data_dir, 'data_train_normalized.npy'))
    val_data = np.load(os.path.join(args.qa_data_dir, 'data_val_normalized.npy'))
    test_data = np.load(os.path.join(args.qa_data_dir, 'data_test_normalized.npy'))

    with open(os.path.join(args.qa_data_dir, 'scaler.pkl'), 'rb') as f:
        scaler = pickle.load(f)

    adj_matrix = np.load(os.path.join(args.qa_data_dir, 'adjacency_matrix.npy')).astype(np.float32)

    # 计算邻居聚合特征
    adj = adj_matrix.copy()
    np.fill_diagonal(adj, 1.0)
    row_sums = adj.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    adj_norm = adj / row_sums
    
    adj2 = adj_norm @ adj_norm
    row_sums2 = adj2.sum(axis=1, keepdims=True)
    row_sums2[row_sums2 == 0] = 1.0
    adj2_norm = adj2 / row_sums2
    
    train_neighbor_1hop = train_data @ adj_norm.T
    val_neighbor_1hop = val_data @ adj_norm.T
    test_neighbor_1hop = test_data @ adj_norm.T
    
    train_neighbor_2hop = train_data @ adj2_norm.T
    val_neighbor_2hop = val_data @ adj2_norm.T
    test_neighbor_2hop = test_data @ adj2_norm.T
    
    if is_main:
        print(f"邻接矩阵: {adj.shape}, 1阶边数: {(adj > 0).sum() - adj.shape[0]}, 2阶边数: {(adj2 > 0).sum() - adj.shape[0]}")
    
    # 计算多尺度特征
    def compute_multiscale_features(data):
        T, N = data.shape
        multiscale = np.zeros((T, N, 3), dtype=np.float32)
        day_steps = 288
        week_steps = 288 * 7
        for t in range(T):
            if t >= day_steps:
                multiscale[t, :, 0] = data[t, :] - data[t - day_steps, :]
            if t >= week_steps:
                multiscale[t, :, 1] = data[t, :] - data[t - week_steps, :]
            if t >= 12:
                multiscale[t, :, 2] = data[t, :] - data[t-12:t, :].mean(axis=0)
        return multiscale
    
    if is_main:
        print("计算多尺度特征...")
    train_multiscale = compute_multiscale_features(train_data)
    val_multiscale = compute_multiscale_features(val_data)
    test_multiscale = compute_multiscale_features(test_data)

    if is_main:
        print(f"归一化训练数据: {train_data.shape}")
        print(f"归一化验证数据: {val_data.shape}")
        print(f"归一化测试数据: {test_data.shape}")

    num_nodes = train_data.shape[1]
    train_end = train_data.shape[0]
    val_end = train_end + val_data.shape[0]

    node_features = compute_node_features(train_data) if is_main else None
    if world_size > 1:
        dist.barrier()
    if not is_main:
        node_features = compute_node_features(train_data)
    
    gcn_embeddings = precompute_gcn_embeddings(
        adj_matrix, node_features, gcn_output_dim=config['gcn_dim'], device=device
    )

    # 创建数据集
    train_dataset = FlowQADataset(
        json_path=os.path.join(args.qa_data_dir, 'flow_train.json'),
        data_matrix=train_data,
        neighbor_1hop=train_neighbor_1hop,
        neighbor_2hop=train_neighbor_2hop,
        multiscale=train_multiscale,
        gcn_embeddings=gcn_embeddings,
        start_time_idx=0,
        lookback=config['lookback'], predict=config['predict']
    )
    val_dataset = FlowQADataset(
        json_path=os.path.join(args.qa_data_dir, 'flow_val.json'),
        data_matrix=val_data,
        neighbor_1hop=val_neighbor_1hop,
        neighbor_2hop=val_neighbor_2hop,
        multiscale=val_multiscale,
        gcn_embeddings=gcn_embeddings,
        start_time_idx=train_end,
        lookback=config['lookback'], predict=config['predict']
    )
    test_dataset = FlowQADataset(
        json_path=os.path.join(args.qa_data_dir, 'flow_test.json'),
        data_matrix=test_data,
        neighbor_1hop=test_neighbor_1hop,
        neighbor_2hop=test_neighbor_2hop,
        multiscale=test_multiscale,
        gcn_embeddings=gcn_embeddings,
        start_time_idx=val_end,
        lookback=config['lookback'], predict=config['predict']
    )

    # 使用 DistributedSampler
    train_sampler = DistributedSampler(train_dataset, num_replicas=world_size, rank=rank, shuffle=True) if world_size > 1 else None
    val_sampler = DistributedSampler(val_dataset, num_replicas=world_size, rank=rank, shuffle=False) if world_size > 1 else None
    test_sampler = DistributedSampler(test_dataset, num_replicas=world_size, rank=rank, shuffle=False) if world_size > 1 else None
    
    train_loader = DataLoader(
        train_dataset, 
        batch_size=config['batch_size'],
        shuffle=(train_sampler is None),
        sampler=train_sampler,
        num_workers=config['num_workers'], 
        pin_memory=True
    )
    val_loader = DataLoader(
        val_dataset, 
        batch_size=config['batch_size'],
        shuffle=False, 
        sampler=val_sampler,
        num_workers=config['num_workers'], 
        pin_memory=True
    )
    test_loader = DataLoader(
        test_dataset, 
        batch_size=config['batch_size'],
        shuffle=False, 
        sampler=test_sampler,
        num_workers=config['num_workers'], 
        pin_memory=True
    )

    if is_main:
        print("\n加载GRU ST Encoder...")
    st_encoder = GRUEncoder(
        hidden_channels=config['st_hidden_dim'],
        num_layers=config['st_num_layers'],
        dropout=config['st_dropout'],
        lookback=config['lookback'],
        out_dim=config['st_hidden_dim']
    ).to(device)

    st_encoder_loaded = False
    try:
        if os.path.exists(config['st_encoder_path']):
            checkpoint = torch.load(config['st_encoder_path'], map_location=device)
            model_dict = st_encoder.state_dict()
            
            compatible_dict = {}
            for k, v in checkpoint.items():
                if k in model_dict and model_dict[k].shape == v.shape:
                    compatible_dict[k] = v
            
            model_dict.update(compatible_dict)
            st_encoder.load_state_dict(model_dict, strict=False)
            st_encoder.eval()
            for param in st_encoder.parameters():
                param.requires_grad = False
            if is_main:
                print(f"GRU ST Encoder已加载并冻结: {config['st_encoder_path']}")
                print(f"   加载了 {len(compatible_dict)} 个兼容的层")
            st_encoder_loaded = True
        else:
            if is_main:
                print(f"GRU ST Encoder文件不存在: {config['st_encoder_path']}")
    except Exception as e:
        if is_main:
            print(f"GRU ST Encoder加载失败: {e}")

    if not st_encoder_loaded and is_main:
        print("将使用随机初始化的GRU Encoder")

    if is_main:
        print("\n创建Llama LoRA模型...")
    model = LlamaLoRAPredictor(
        llama_model_path=config['llama_model_path'],
        st_hidden_dim=config['st_hidden_dim'],
        spatial_dim=config['spatial_dim'],
        lora_r=config['lora_r'],
        lora_alpha=config['lora_alpha'],
        dropout=config['lora_dropout']
    )
    model = model.to(device)
    
    # 使用 DDP 包装模型
    if world_size > 1:
        model = DDP(model, device_ids=[local_gpu_id], find_unused_parameters=True)
    
    # 获取实际模型（用于访问 tokenizer 等属性）
    actual_model = model.module if world_size > 1 else model

    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in model.parameters())
    if is_main:
        print(f"参数: {trainable_params / 1e6:.1f}M / {total_params / 1e9:.2f}B (可训练/总)")

    optimizer = optim.AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=config['learning_rate'],
        weight_decay=1e-5,
        betas=(0.9, 0.999)
    )

    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=5, T_mult=2, eta_min=1e-7
    )

    if is_main:
        print("\n开始训练...")
        print("="*60)

    history = []
    start_time = time.time()
    
    # 早停相关变量
    best_val_mae = float('inf')
    patience_counter = 0
    best_model_state = None

    for epoch in range(config['epochs']):
        epoch_start = time.time()
        
        # DDP: 每个 epoch 设置 sampler
        if train_sampler is not None:
            train_sampler.set_epoch(epoch)

        # 训练
        train_loss = train_epoch_ddp(model, actual_model, train_loader, optimizer, device,
                                     st_encoder, config['instruction'], is_main)

        scheduler.step()
        
        # 验证（所有进程都执行，内部会做聚合）
        val_mae, val_rmse, val_mape = validate_epoch_ddp(
            model, actual_model, val_loader, device, 
            st_encoder, config['instruction'], scaler, is_main
        )
        
        # 同步所有进程
        if world_size > 1:
            dist.barrier()

        epoch_time = time.time() - epoch_start

        if is_main:
            # 检查是否是最佳模型
            improved = val_mae < best_val_mae
            if improved:
                best_val_mae = val_mae
                patience_counter = 0
                best_model_state = {k: v.cpu().clone() for k, v in actual_model.state_dict().items()}
                improve_mark = " *"
            else:
                patience_counter += 1
                improve_mark = ""
            
            print(f"Epoch {epoch+1:3d}/{config['epochs']} | "
                  f"Train Loss: {train_loss:6.4f} | "
                  f"Val MAE: {val_mae:.4f} | Val RMSE: {val_rmse:.4f} | Val MAPE: {val_mape:.2f}% | "
                  f"LR: {optimizer.param_groups[0]['lr']:.6f} | "
                  f"Time: {epoch_time:.1f}s{improve_mark}")

            history.append({
                "epoch": int(epoch + 1),
                "train_loss": float(train_loss),
                "val_mae": float(val_mae),
                "val_rmse": float(val_rmse),
                "val_mape": float(val_mape),
                "lr": float(optimizer.param_groups[0]['lr']),
                "epoch_time": float(epoch_time),
            })
            
            # 早停检查
            if patience_counter >= config['patience']:
                print(f"\n早停触发! 验证 MAE 连续 {config['patience']} 个 epoch 未改善")
                break

    total_time = time.time() - start_time
    
    if is_main:
        print("="*60)
        print(f"训练完成! 耗时: {total_time/60:.1f} 分钟")
        print(f"最佳验证 MAE: {best_val_mae:.4f}")

    # 保存并同步最佳模型权重
    model_save_path = os.path.join(config['output_dir'], 'llama_lora_model_gru.pth')
    if world_size > 1 and dist.is_initialized():
        # 仅主进程写盘
        if is_main:
            if best_model_state is not None:
                torch.save(best_model_state, model_save_path)
            else:
                torch.save(actual_model.state_dict(), model_save_path)
            print(f"模型已保存: {model_save_path}")
        # 等待保存完成
        dist.barrier()
        # 所有进程从同一 checkpoint 加载，保证测试时权重一致
        ckpt = torch.load(model_save_path, map_location=device)
        actual_model.load_state_dict(ckpt)
    else:
        # 单卡或未初始化 DDP: 保持原有逻辑
        if best_model_state is not None:
            torch.save(best_model_state, model_save_path)
            actual_model.load_state_dict(best_model_state)
        else:
            torch.save(actual_model.state_dict(), model_save_path)
        if is_main:
            print(f"模型已保存: {model_save_path}")

    # ==================== 测试集评估（支持 DDP 聚合） ====================
    if is_main:
        print("\n测试集评估...")

    if world_size > 1 and dist.is_initialized():
        (test_mae, test_rmse, test_mape), detailed_stats = evaluate_and_collect_stats_ddp(
            actual_model, test_loader, device, st_encoder, config['instruction'], scaler, config, test_data.shape, is_main
        )
    else:
        (test_mae, test_rmse, test_mape), detailed_stats = evaluate_and_collect_stats(
            actual_model, test_loader, device, st_encoder, config['instruction'], scaler, config, test_data.shape
        )

    if is_main:
        data_range = scaler.data_range_.mean()
        actual_test_mae = test_mae * data_range
        actual_test_rmse = test_rmse * data_range
        actual_test_mape = test_mape

        print(f"\n" + "="*60)
        print("测试集结果:")
        print(f"  归一化 MAE: {test_mae:.4f}")
        print(f"  归一化 RMSE: {test_rmse:.4f}")
        print(f"  归一化 MAPE: {test_mape:.2f}%")
        print(f"  实际 MAE: {actual_test_mae:.3f}")
        print(f"  实际 RMSE: {actual_test_rmse:.3f}")
        print(f"  实际 MAPE: {actual_test_mape:.2f}%")
        print("="*60)

        results = {
            'config': {k: str(v) if not isinstance(v, (int, float, str, list, dict, type(None))) else v for k, v in config.items()},
            'best_val_mae': float(best_val_mae),
            'test_mae': float(test_mae),
            'test_rmse': float(test_rmse),
            'test_mape': float(test_mape),
            'actual_test_mae': float(actual_test_mae),
            'actual_test_rmse': float(actual_test_rmse),
            'actual_test_mape': float(actual_test_mape),
            'total_time_minutes': total_time / 60,
            'history': history,
        }

        results_path = os.path.join(config['output_dir'], 'llama_lora_results_gru.json')
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"结果已保存: {results_path}")

        # ==================== 画图与数据保存 ====================
        print("\n生成图表...")
        
        horizon = config['predict']
        mae_per_h = detailed_stats['mae_per_h']
        rmse_per_h = detailed_stats['rmse_per_h']
        mape_per_h = detailed_stats['mape_per_h']
        pred_series = detailed_stats['pred_series']
        pred_counts = detailed_stats['pred_counts']
        
        mae_per_h_actual = mae_per_h * data_range
        rmse_per_h_actual = rmse_per_h * data_range
        horizons = np.arange(1, horizon + 1)
        
        # 1) MAE per horizon
        plt.figure(figsize=(10, 6))
        plt.plot(horizons, mae_per_h_actual, marker='o', color='steelblue', linewidth=2, markersize=8)
        plt.xlabel('Prediction Horizon', fontsize=12)
        plt.ylabel('MAE (Actual Scale)', fontsize=12)
        plt.title('GRU Model - MAE by Prediction Horizon', fontsize=14)
        plt.xticks(horizons)
        y_max = max(mae_per_h_actual) * 1.15 if len(mae_per_h_actual) > 0 else 1.0
        plt.ylim(0, y_max)
        plt.grid(True, alpha=0.3)
        for i, v in enumerate(mae_per_h_actual):
            plt.text(i+1, v + y_max * 0.02, f'{v:.1f}', ha='center', fontsize=9)
        plt.tight_layout()
        mae_path = os.path.join(config['output_dir'], 'test_horizon_mae.png')
        plt.savefig(mae_path)
        plt.close()
        
        # 2) RMSE per horizon
        plt.figure(figsize=(10, 6))
        plt.plot(horizons, rmse_per_h_actual, marker='s', color='coral', linewidth=2, markersize=8)
        plt.xlabel('Prediction Horizon', fontsize=12)
        plt.ylabel('RMSE (Actual Scale)', fontsize=12)
        plt.title('GRU Model - RMSE by Prediction Horizon', fontsize=14)
        plt.xticks(horizons)
        y_max = max(rmse_per_h_actual) * 1.15 if len(rmse_per_h_actual) > 0 else 1.0
        plt.ylim(0, y_max)
        plt.grid(True, alpha=0.3)
        for i, v in enumerate(rmse_per_h_actual):
            plt.text(i+1, v + y_max * 0.02, f'{v:.1f}', ha='center', fontsize=9)
        plt.tight_layout()
        rmse_path = os.path.join(config['output_dir'], 'test_horizon_rmse.png')
        plt.savefig(rmse_path)
        plt.close()
        
        # 3) MAPE per horizon
        plt.figure(figsize=(10, 6))
        plt.plot(horizons, mape_per_h, marker='^', color='forestgreen', linewidth=2, markersize=8)
        plt.xlabel('Prediction Horizon', fontsize=12)
        plt.ylabel('MAPE (%)', fontsize=12)
        plt.title('GRU Model - MAPE by Prediction Horizon', fontsize=14)
        plt.xticks(horizons)
        y_max = max(mape_per_h) * 1.15 if len(mape_per_h) > 0 else 1.0
        plt.ylim(0, y_max)
        plt.grid(True, alpha=0.3)
        for i, v in enumerate(mape_per_h):
            plt.text(i+1, v + y_max * 0.02, f'{v:.1f}%', ha='center', fontsize=9)
        plt.tight_layout()
        mape_path = os.path.join(config['output_dir'], 'test_horizon_mape.png')
        plt.savefig(mape_path)
        plt.close()
        
        # 4) 时间序列对比（两个节点）
        pred_avg = np.divide(pred_series, pred_counts, where=pred_counts > 0, out=np.zeros_like(pred_series))
        pred_avg_actual = pred_avg * data_range
        true_actual = test_data * data_range
        
        num_timesteps, num_nodes = test_data.shape
        node1, node2 = 0, min(50, num_nodes - 1)
        
        fig, axes = plt.subplots(2, 1, figsize=(16, 8), sharex=True)
        for ax, node in zip(axes, [node1, node2]):
            ax.plot(range(num_timesteps), true_actual[:, node], label='True', alpha=0.7, linewidth=0.8)
            ax.plot(range(num_timesteps), pred_avg_actual[:, node], label='Predicted', alpha=0.7, linewidth=0.8, linestyle='--')
            ax.set_ylabel(f'Node {node} Flow', fontsize=11)
            ax.legend(loc='upper right')
            ax.grid(alpha=0.3)
        axes[0].set_title('GRU Model - Traffic Flow Prediction vs Ground Truth', fontsize=14)
        axes[1].set_xlabel('Time Step', fontsize=12)
        plt.tight_layout()
        ts_path = os.path.join(config['output_dir'], 'test_two_nodes_prediction.png')
        plt.savefig(ts_path)
        plt.close()
        
        print(f"\n图表已保存:")
        print(f"   MAE:  {mae_path}")
        print(f"   RMSE: {rmse_path}")
        print(f"   MAPE: {mape_path}")
        print(f"   时间序列: {ts_path}")
        
        # 保存画图数据 JSON（与 test_plot_data.json 结构一致）
        plot_data = {
            'horizons': list(range(1, horizon + 1)),
            'mae_per_horizon': mae_per_h_actual.tolist(),
            'rmse_per_horizon': rmse_per_h_actual.tolist(),
            'mape_per_horizon': mape_per_h.tolist(),
            'node_ids': [node1, node2],
            'node_true': {
                str(node1): true_actual[:, node1].tolist(),
                str(node2): true_actual[:, node2].tolist(),
            },
            'node_pred': {
                str(node1): pred_avg_actual[:, node1].tolist(),
                str(node2): pred_avg_actual[:, node2].tolist(),
            },
        }
        plot_data_path = os.path.join(config['output_dir'], 'test_plot_data.json')
        with open(plot_data_path, 'w', encoding='utf-8') as f:
            json.dump(plot_data, f, ensure_ascii=False, indent=2)
        print(f"   画图数据 JSON: {plot_data_path}")
        
        # 更新 results 并重新保存（包含画图数据）
        results['horizons'] = list(range(1, horizon + 1))
        results['mae_per_horizon'] = mae_per_h_actual.tolist()
        results['rmse_per_horizon'] = rmse_per_h_actual.tolist()
        results['mape_per_horizon'] = mape_per_h.tolist()
        results['node_ids'] = [node1, node2]
        results['node_true'] = {
            str(node1): true_actual[:, node1].tolist(),
            str(node2): true_actual[:, node2].tolist(),
        }
        results['node_pred'] = {
            str(node1): pred_avg_actual[:, node1].tolist(),
            str(node2): pred_avg_actual[:, node2].tolist(),
        }
        
        with open(results_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"   结果 JSON (含画图数据): {results_path}")
        
        print("\n" + "="*60)
        print("训练与评估全部完成!")
        print("="*60)

    # 清理 DDP
    if world_size > 1:
        cleanup_ddp()


def validate_epoch_ddp(model, actual_model, loader, device, st_encoder=None, instruction=None, scaler=None, is_main=True):
    """DDP 版本的验证函数，支持多卡并行验证和指标聚合"""
    model.eval()
    if st_encoder is not None:
        st_encoder.eval()

    # 本地指标累积
    local_metrics = torch.zeros(4, device=device) # mae, rmse, mape, count
    
    loader_iter = tqdm(loader, desc="Validating", leave=False) if is_main else loader
    
    with torch.no_grad():
        for batch_data in loader_iter:
            x, n1, n2, ms, time_feat, spatial_enc, y, y_text, _ = batch_data
            x = x.to(device)
            n1 = n1.to(device)
            n2 = n2.to(device)
            ms = ms.to(device)
            time_feat = time_feat.to(device)
            spatial_enc = spatial_enc.to(device)
            y = y.to(device)

            st_features = None
            if st_encoder is not None:
                st_features = st_encoder(x, n1, n2, ms, time_feat)

            try:
                # 生成预测文本
                generated_texts = actual_model.forward_generate(x, spatial_enc, st_features, instruction, max_new_tokens=100)

                for i, text in enumerate(generated_texts):
                    pred_values = parse_answer_text(text)

                    if pred_values is not None:
                        pred_values = pred_values.to(device)
                        pred_values = torch.clamp(pred_values, 0.0, 1.0)
                    else:
                        pred_values = torch.full((y.shape[1],), 0.5, device=device)

                    # 使用 compute_metrics 保持一致性
                    mae, rmse, mape = compute_metrics(pred_values, y[i], scaler)
                    
                    local_metrics[0] += mae
                    local_metrics[1] += rmse
                    local_metrics[2] += mape
                    local_metrics[3] += 1.0

            except Exception as e:
                if is_main:
                    print(f"\nError in validation batch: {e}")
                continue

    # 多卡聚合指标
    if dist.is_initialized():
        dist.all_reduce(local_metrics, op=dist.ReduceOp.SUM)

    global_mae = local_metrics[0].item()
    global_rmse = local_metrics[1].item()
    global_mape = local_metrics[2].item()
    total_samples = local_metrics[3].item()

    avg_mae = global_mae / max(total_samples, 1)
    avg_rmse = global_rmse / max(total_samples, 1)
    avg_mape = global_mape / max(total_samples, 1)
    
    return avg_mae, avg_rmse, avg_mape


def train_epoch_ddp(model, actual_model, loader, optimizer, device, st_encoder=None, instruction=None, is_main=True):
    """DDP 版本的训练函数"""
    model.train()
    if st_encoder is not None:
        st_encoder.eval()

    total_loss = 0
    num_batches = 0
    
    loader_iter = tqdm(loader, desc="Training", leave=False) if is_main else loader
    
    for batch_data in loader_iter:
        x, n1, n2, ms, time_feat, spatial_enc, y, y_text, _ = batch_data
        x = x.to(device)
        n1 = n1.to(device)
        n2 = n2.to(device)
        ms = ms.to(device)
        time_feat = time_feat.to(device)
        spatial_enc = spatial_enc.to(device)
        y = y.to(device)

        st_features = None
        if st_encoder is not None:
            with torch.no_grad():
                st_features = st_encoder(x, n1, n2, ms, time_feat)

        try:
            answer_tokens = actual_model.tokenizer(
                y_text,
                return_tensors='pt',
                padding=True,
                truncation=True,
                max_length=128
            ).to(device)
            answer_input_ids = answer_tokens['input_ids']

            loss = model(x, spatial_enc, st_features, answer_input_ids=answer_input_ids, instruction=instruction, mode='train')

            if loss.ndim > 0:
                loss = loss.mean()

            if torch.isnan(loss) or torch.isinf(loss):
                if is_main:
                    print(f"\nNaN/Inf detected in loss! Skipping batch...")
                continue

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            total_loss += loss.item()
            num_batches += 1
        except Exception as e:
            if is_main:
                print(f"\nError in batch: {e}")
            continue

    return total_loss / max(num_batches, 1)


def main():
    """主函数 - DDP 多卡并行版本"""
    import torch.multiprocessing as mp
    
    parser = argparse.ArgumentParser(description='Llama LoRA时空预测训练 - GRU版本 (DDP多卡)')
    parser.add_argument('--qa_data_dir', type=str,
                       default='/data/wangyuehao/preflows/urbangpt_new/qa_data',
                       help='QA数据目录')
    parser.add_argument('--llama_model_path', type=str,
                       default='/data/wangyuehao/preflows/meta-llama/Llama-3.2-1B',
                       help='Llama模型路径')
    parser.add_argument('--st_encoder_path', type=str,
                       default='/data/wangyuehao/preflows/urbangpt_new/best_model_time_gru_12.96.pth',
                       help='GRU ST Encoder模型路径')
    parser.add_argument('--output_dir', type=str,
                       default='/data/wangyuehao/preflows/urbangpt_new',
                       help='输出目录')
    parser.add_argument('--gpu_ids', type=str, default='0,1',
                       help='使用的GPU编号，用逗号分隔，例如 0,1,2,3')
    parser.add_argument('--batch_size', type=int, default=96,
                       help='每张卡的批次大小')
    parser.add_argument('--epochs', type=int, default=3,
                       help='训练轮数')
    parser.add_argument('--learning_rate', type=float, default=0.0001,
                       help='学习率')
    parser.add_argument('--master_port', type=str, default='12355',
                       help='DDP master port')

    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 解析 GPU IDs
    gpu_ids = [int(x.strip()) for x in args.gpu_ids.split(',')]
    world_size = len(gpu_ids)
    
    print("="*60)
    print("Llama LoRA时空预测训练 - GRU增强版 (DDP)")
    print("="*60)
    print(f"使用 GPU: {gpu_ids} (共 {world_size} 卡)")
    print(f"每卡 Batch Size: {args.batch_size}")
    print(f"总有效 Batch Size: {args.batch_size * world_size}")
    
    if world_size > 1:
        # 多卡: 使用 mp.spawn 启动多进程
        mp.spawn(
            main_worker,
            args=(world_size, gpu_ids, args),
            nprocs=world_size,
            join=True
        )
    else:
        # 单卡: 直接调用
        main_worker(0, 1, gpu_ids, args)


if __name__ == "__main__":
    main()
